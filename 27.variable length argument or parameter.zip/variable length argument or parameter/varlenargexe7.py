def findsumavg(sname,*n,cls="XII"):

    print("="*50)
    print("\tStudent name:{} from {} class".format(sname,cls))
    print("="*50)
    s=0
    for val in n:
        print("\t\t{}".format(val))
        s=s+val
    else:
        print("="*50)
        print("\tSum of ={} out of 500".format(s))
        print("\tAverage of={} out of 100".format(s/len(n)))
        Average=(s/len(n))
        grade="FAIL"
        grades="PASS"
        if(Average<=50):
            print("\tGrade={}".format(grade))
        else:
            print("\tGrade={}".format(grades))
            
#main programm
findsumavg("Travis",45,67,93,47,99)
findsumavg("Tejas",34,23,56,34,44,cls="B-Tech")
findsumavg("Guido",90,67,78,98,65)
findsumavg("Rossum",44,32,23,37,40,cls="M-Tech")
    
