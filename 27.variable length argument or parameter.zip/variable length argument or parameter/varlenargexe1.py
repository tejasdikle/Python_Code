def disp(a):
    print("\t{}".format(a))
disp(10)

def disp(a,b):
    print("\t{}\t{}".format(a,b))
disp(10,20)

def disp(a,b,c):
    print("\t{}\t{}\t{}".format(a,b,c))
disp(10,20,30)


    

