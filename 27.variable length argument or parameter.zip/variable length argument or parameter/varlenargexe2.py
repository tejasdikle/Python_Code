def disp(*n):
    print("="*50)
    print("type of n={} and number of element={}".format(type(n),len(n)))
    print("="*50)
    for val in n:
        print("\t{}".format(val))
    else:
        print("="*50)




#main programm
disp(10)
disp(10,20)
disp(10,20,30)
disp(10,20,30,"PYTHON")
disp("c","cpp","Java","Python","django")
disp()
