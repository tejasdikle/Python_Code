def disp(*n,crs="PYTHON"):
    print("="*50)
    print("Type of n={} and number of value ={}".format(type(n),len(n)))
    print("Type of course=",crs)
    print("="*50)
    for val in n:
        print("\t{}".format(val))
    else:
        print("="*50)




#main programm
disp(10)
disp(10,20)
disp(10,20,30)
disp(10,20,30,40,'python')
disp('c','cpp','java','django','html')
disp()
