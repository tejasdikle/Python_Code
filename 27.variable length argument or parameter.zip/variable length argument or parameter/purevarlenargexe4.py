def findsumavg(sname,*n):

    print("="*50)
    print("Name of person:{}".format(sname))
    print("="*50)
    s=0
    for val in n :
        print("\t{}".format(val))
        s=s+val

    else:
        print("="*50)
        print("Sum of ={}".format(s))
        #print("Average={}".format(s/len(s)))
        print("="*50)
#main programm
findsumavg("Rossum",30,20,40,30,30,30)
findsumavg("Travis",30,40,50)
findsumavg("Kinney",30,40,60)
findsumavg("Golsing",30)
