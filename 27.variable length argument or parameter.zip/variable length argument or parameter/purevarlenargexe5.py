#def findsumavg(sname,city="HYDRABAD",*n):
def findsumavg(sname,*n,city="HYDRABAD"):
    print("="*50)
    print("Name of person :{} and live from ={}".format(sname,city))
    print("="*50)
    s=0
    for val in n:
        print("\t{}".format(val))
        s=s+val
    else:
        if(len(n)!=0):
            print("="*50)
            print("Sum of ={} ".format(s))
            print("Average of={}".format(s/len(n)))
            print("="*50)
        else:
            print("="*50)
            print("Sum of ={} ".format(s))
            print("Average of={}".format(s/len(n)))
            print("="*50)
#main programm
findsumavg("TRAVIS",30.40,20,50,-20)
findsumavg("TEJAS",90.8,30,20,990,city="MUMBAI")
findsumavg("GOSLING",98.3,12,1120)
findsumavg("MADRAS",90,23,2334,12,city="DUBAI")
            
