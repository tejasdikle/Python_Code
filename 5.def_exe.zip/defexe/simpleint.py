def simpleint(P,T,R):
    SI=(P*T*R)/100
    TOTAMT=SI+P
    return SI,TOTAMT
#main programm
P=float(input("Enter principle amount:"))
T=float(input("Enter time:"))
R=float(input("Enter rate of interest:"))

#function call
SI,TOTAMT=simpleint(P,T,R)
print("="*50)
print("simple interest amount:{}".format(SI))
print("Total aoumt to pay the customer:{}".format(TOTAMT))
print("="*50)   
