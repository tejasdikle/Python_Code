#text split
text='python is an oop langauge '
ln=list(text)
print(ln)
