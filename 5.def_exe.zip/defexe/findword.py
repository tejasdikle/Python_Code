def readtext():
    text=input("Enter a text:")
    lst=text.split()
    return lst
def searchword(wrd1,lst1):
    if wrd1 in lst:
        return True
    else:
        return False
#main programm
lst=readtext()
wrd=input("Enter a word to search in list :")
result=searchword(wrd,lst)
if(result):
    print("Search is successful ")
else:
    print("Search is Un-successful")
