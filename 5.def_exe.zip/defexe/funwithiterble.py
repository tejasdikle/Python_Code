def disp(kv):
    print("="*50)
    print("Type of kv disp fun =",type(kv))
    print("="*50)
    for v in kv:
        print("\t{}".format(v))
def show(ab):
    print("="*50)
    print("Type of ab show fun =",type(ab))
    print("="*50)
    for x,y in ab.items():
        print("\t{}------>{}".format(x,y))


#main programm
lst=[10,20,30,40,"Python"]
disp(lst)
tp=(10,20,30,40,"Python")
disp(tp)
fs=frozenset({10,20,30,'tejas',"JAVA"})
disp(fs)
s='PYTHON'
disp(s)
d={10:'python',20:'java',30:'kivi'}
show(d)
