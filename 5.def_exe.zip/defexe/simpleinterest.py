def disp(kv):
    print("="*50)
    print("\tTypes of kv=",type(kv))
    print("="*50)
    for v,w in kv.items():
        print("\t{}----->".format(v,w))
#main programm
lst=[10,20,30,40,50,"python","kivi"]
disp(lst)
tp=(10,20,30,40,50,"tejas")
disp(tp)
fs=frozenset({10,20,30,"python","django"})
disp(fs)
d={10:'tejas',20:'rahul',30:'father'}
disp(d)
