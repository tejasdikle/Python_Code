def readlistvalue():
    n=int(input("Enter number u want to write:"))
    if(n<=0):
        print("Invalid number")
    else:
        lst=[]
        for i in range (1,n+1):
            val=int(input("Enter {} value".format(i)))
            lst.append(val)
        return(lst)
def findlistsumavg(lst):
    s=0
    for val in lst:
        s=s+val
    else:
        print("Sum of {}".format(s))
        print("Avarage={}".format(s/len(lst)))
#main programm
kvlist=readlistvalue()
print("="*50)
print("Content in list=",kvlist)
print("="*50)
findlistsumavg(kvlist)
