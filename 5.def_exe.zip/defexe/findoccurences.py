#findoccurences
import time
def findoccerences():
    line=input("Enter line of text:")
    lst=list(line)
    print("======================================")
    print("Original line {}".format(line))
    print("========================================")
    for ch in line:
        print("Character :{} and number of occurences {}".format(ch,lst.count(ch)))
        time.sleep(1)
    else:
        print("====================================")
findoccerences()
