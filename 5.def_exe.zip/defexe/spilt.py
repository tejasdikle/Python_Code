test='python is an oop langauges'
ls=test.split()
print(ls)
