#mulex2.py
def mulop():
    #input
    a=float(input("Enter value of a:"))
    b=float(input("Enter valure of b:"))
    #main programm
    c=a*b
    #display
    print("\tmultiplication of\n\t({},{})={}".format(a,b,c))
    #main program
mulop()
