#mulexe5.py
def mulop():
    #taking input
    x=float(input("Enter first value :"))
    y=float(input("Enter second value :"))
    #process
    a=x*y
    
    #result
    return a
#main programm
res=mulop()
print("mul result=",res)

