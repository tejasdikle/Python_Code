#mulex5.py
def mulop(a,b):
    c=a*b
    return c
#main programm
x=float(input("Enter value of a :"))
y=float(input("Enter value of b :"))
res=mulop(x,y)
print("mul ({},{})={}".format(x,y,res))
