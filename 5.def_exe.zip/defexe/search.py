def readtext():
    text=input("Enter a text:")
    lst=text.split()
    
    return lst
def searchword(lst,wrd):
    if wrd in lst:
        return True
    else:
        return False
#main programm
lst=readtext()
wrd=input("Enter a word to serch in list of word:")
result=searchword(lst,wrd)
if(result):
    print("Search is successful")
else:
    print("Search is unsuccessful")
    
