#arearectexe6.py
def arearect(l,b):
    arearect=l*b
    return arearect
#main programm
l=float(input("Enter length :"))
b=float(input("Enter breadth"))
res=arearect(l,b)
print("Area of reactangle {}".format(res))
