#mulex2.py
def mulop(a,b):
    c=a-b
    return c
#main program
x=float(input("Enter first value:"))
y=float(input("Enter second value:"))
result=mulop(x,y)
print("mul({},{})={}".format(x,y,result))
