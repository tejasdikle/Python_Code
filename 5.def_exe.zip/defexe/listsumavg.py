#readlistvalue.py
def readlistvalue():
    n=int(input("Enter how many value you want write:"))
    if(n<=0):
        print("{} invalid input ".format(n))
    else:
        lst=[]
        for i in range (1,n+1):
            val= float(input("Enter {} value:".format(i)))
            lst.append(val)
        return lst
def findlistsumavg(lst):
    #find sum & avg
    s=0
    for val in lst:
        s=s+val
        print("\t{}".format(val))
    else:
        print("="*50)
        print("\tsum={}".format(s))
        print("="*50)
        print("\tAvg={}".format(s/len(lst)))
        print("="*50)
ablist=readlistvalue()
print("="*50)
print("Content in list=",ablist)
print("="*50)
findlistsumavg(ablist)
    
