import time
def showinfo(sno,sname,marks,crs='python'):

    print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))
    time.sleep(1)
print("="*50)
print("\tsno\tsname\tmarks\tcrs")
print("="*50)
showinfo(111,'Sj',45.58,'java')
showinfo(222,'ST',38.44)
showinfo(333,'RT',76.34)
showinfo(444,'WK',88.23,'.NET')
print("="*50)
