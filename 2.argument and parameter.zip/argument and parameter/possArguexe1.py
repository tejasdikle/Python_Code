def disp(a,b,c):
    d=(a+b+c)
    print("Result =",d)
    
#main programm
disp(10,60,70)
disp(40,50,80)
disp(50,40,90)
disp(60,10,40)
disp(20,30,20)

