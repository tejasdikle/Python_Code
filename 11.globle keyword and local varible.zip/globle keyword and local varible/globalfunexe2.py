a=10
b=20
c=30
d=40
def operation():
    a1=100
    b1=200
    c1=300
    d1=400
    res=a+b+c+d+a1+b1+c1+d1
    print(res)
operation()
