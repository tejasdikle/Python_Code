lang="PYTHON"
def learnML():
    sub1="MACHINE LEARNING"
    #lang="PYTHON"
    print("\nTo learn and code in '{}' we use '{}' programming".format(sub1,lang))
def learnDL():
    sub1="DEEP LEARING"
    #lang="PYTHON"
    print("\nTo learn and code in '{}' we use '{}' programming".format(sub1,lang))

def learnIOT():
    sub1="IOT"
    #lang="PYTHON"
    print("\nTo learn and code in '{}' we use '{}' programming".format(sub1,lang))

#main programm

learnML()
learnDL()
learnIOT()
