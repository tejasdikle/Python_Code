#FileOpenEx4.py
import sys
try:
    kvr=open("emp.data","w")
except FileNotFoundError:
    print("File does not exist")
else:
    print("="*50)
    print("Name of file =",kvr.name)
    print("File opening mode=",kvr.mode)
    print("Is emp.data writable=",kvr.writable())
    print("Is emp.data readable=",kvr.readable())
    print("Current file is closed or not=",kvr.closed)
    print("="*50)
    kvr.close()

    print("USING CLOSED OFF FUNCTION")
    print("Current file are closed or not=",kvr.closed)
    print("="*50)
finally:
    print("Thank you for using this programm")
    
    sys.exit()
