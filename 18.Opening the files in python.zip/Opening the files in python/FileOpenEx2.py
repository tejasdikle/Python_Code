#FileOpenEx2.py
kvr=open("Stude.data","w")
print("Stud.data file open successfully-verify")
print("Type of kvr=",type(kvr))
