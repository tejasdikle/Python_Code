#FileOpenEx3.py
try:
    kvr=open("Stud.data","w")
except FileNotFoundError:
    print("File does not exist")
else:
    print("="*50)
    print("File name=",kvr.name)
    print("Mode of file=",kvr.mode)
    print("Stud.data is writable=",kvr.writable())
    print("Stud.data is readable=",kvr.readable())
    print("Stud.data is closed=",kvr.closed)
    print("="*50)
finally:
    print("I am from finally block")
    kvr.close()
    print("Stud.data is closed=",kvr.closed)
    print("="*50)
