addr=[10,20,30,'tejas','pandey','khatrri']
with open("stud1.data","a")as fp:
    fp.writelines(str(addr)+"\n")
    print("Data save seccssfully")
