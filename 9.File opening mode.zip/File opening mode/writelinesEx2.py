addr={10:"tejas",20:"rahul",30:"karan",40:"nana"}
with open("stud3.data","a")as fp:
    fp.writelines(str(addr)+"\n")
    print("Data save successfully")
