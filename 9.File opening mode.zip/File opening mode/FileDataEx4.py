try:
    amd=open("stud.data","r")
except FileNotFoundError:
    print("File does not exist")
else:
     print("FIle opened in write mode successfully-verify")
     print("Name of file=",amd.name)
     print("File open mode =",amd.mode)
     print("Is writable=",amd.writable())
     print("Is readable=",amd.readable())
     print("File are close=",amd.closed)
finally:
    print("="*50)
    print("I am from finally block")
    amd.close()
    print("="*50)
    print("File are close=",amd.closed)
   
