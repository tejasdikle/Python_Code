import sys

try:
    al=open("emp.data","a+")
except FileNotFoundError:
    print("File does not exist")
else:
    print("File open in read mode successfully")
    print("file name=",al.name)
    print("file opening mode=",al.mode)
    print("Is emp data file readable=",al.readable())
    print("Is emp data file writable=",al.writable())
    print("emp data file are closed=",al.closed)
finally:
    al.close()
    print("emp data are closed=",al.closed)
    sys.exit()
