with open("stud.data","w")as fp:
    fp.write("Ajay")
    fp.write("tejas")
    fp.write("malik")
    print("Data save successfully")
