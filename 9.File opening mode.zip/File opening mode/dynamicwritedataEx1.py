with open("Hyd1.data","a")as fp:
    print("Enter the data from keyboard and pressm @ to stop")
    while(True):
        kbd=input()
        if(kbd=="@"):
            exit()
        else:
            fp.write(kbd+"\n")
