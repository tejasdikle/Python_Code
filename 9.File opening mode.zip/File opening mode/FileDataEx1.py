amd=open("stud.data","r")
print("FIle opened in read mode successfully-verify")
 
