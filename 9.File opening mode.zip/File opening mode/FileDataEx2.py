try:
    amd=open("stud.data","r")
except FileNotFoundError:
    print("File does not exist")
else:
     print("FIle opened in read mode successfully-verify")
     print("Name of file=",amd.name)
     print("File open mode =",amd.mode)
     print("Is writable=",amd.writable())
     print("Is readable=",amd.readable())
