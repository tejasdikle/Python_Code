import os
lst=os.listdir(".")
print(type(lst))
