import os
os.removedirs("kvr")
print("Remove successfully")
