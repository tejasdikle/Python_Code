import os
os.rmdir("kvr")
print("Remove successfully")
