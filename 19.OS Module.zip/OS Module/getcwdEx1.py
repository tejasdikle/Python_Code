import os
print("current working folder=",os.getcwd())
