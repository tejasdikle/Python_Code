import os
try:
    os.mkdir("kvr")
    print("Save successfully:")
except FileExistsError:
    print("File allready avaliable ")
                                                                                
