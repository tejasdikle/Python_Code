#teacherinfo.py
tname="kv rao"
subject="Python"
