#icicia.py
import icici
print("="*50)
