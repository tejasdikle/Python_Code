#loancal.py
bname="ICICI"
add="NASHIK"
print("="*50)
print("Bank Name:",bname)
print("Address:",add)
print("="*50)
def loancal():
    p=float(input("Enter the principle amount:"))
    t=float(input("Enter the time period:"))
    r=float(input("Enter the rate of interest:"))
    si=(p*t*r)/100
    print("Simple interest :{}".format(si))


loancal()
