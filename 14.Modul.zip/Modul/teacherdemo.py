#import teacherinfo as t
#print("Teacher name:{}".format(t.tname))
#print("Techer subject:{}".format(t.subject))

from teacherinfo import tname,subject
print("Teacher name:{}".format(tname))
print("Techer subject:{}".format(subject))
