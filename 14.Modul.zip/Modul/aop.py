#aop.py
def addop(a,b):
    print("Addtion of ({},{})={}".format(a,b,a+b))

def subop(a,b):
    print("Substraction of ({},{})={}".format(a,b,a-b))

def mulop(a,b):
    print("Multiplication of ({},{})={}".format(a,b,a*b))
    
