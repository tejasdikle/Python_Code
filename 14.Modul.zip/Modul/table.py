#from multable import*
#table(int(input("Enter the number:")))

import multable
multable.table(int(input("Enter the number:")))
