#operation.py
from aop import addop,subop,mulop
addop(100,20)
subop(100,20)
mulop(20,4)
