from const import PI as p,E as e
print("value of pi:{}".format(p))
print("Value of E:{}".format(e))

"""from const import PI ,E 
print("value of pi:{}".format(p))
print("Value of E:{}".format(e))"""
