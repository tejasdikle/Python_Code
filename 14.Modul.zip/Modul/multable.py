#multable.py
def table(n):
    if(n<=0):
        print("Invalid input")
    else:
        print("="*50)
        print("\tMul table for :{}".format(n))
        print("="*50)
        for i in range (1,11):
            print("\t{}*{}={}".format(n,i,n*i))
        else:
            print("="*50)
