import shares ,time
def dispsharevalue(s):
    print("="*50)
    print("\tshare name \tshare price")
    print("="*50)
    for sn,sp in s.items():
        print("\t{}\t\t{}".format(sn,sp))
        time.sleep(2)
    else:
        print("="*50)
s=shares.sharesinfo()
dispsharevalue(s)
