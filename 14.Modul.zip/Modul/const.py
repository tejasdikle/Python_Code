#ab.py
PI=3.14
E=2.71
