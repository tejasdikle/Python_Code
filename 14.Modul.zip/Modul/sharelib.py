import time,importlib
import sharess
def dispsharesvalue(d):
    print("="*50)
    print("\tShare name\tShare price")
    print("="*50)
    for sn,sp in d.items():
        print("\t{}\t\t{}".format(sn,sp))
    print("="*50)

#main program
d=sharess.sharesinfo()
dispsharesvalue(d)
time.sleep(2)
importlib.reload(sharess)
d=sharess.sharesinfo()
dispsharesvalue(d)
