#shares.py
def sharesinfo():
    s={"IT":12,"MG":34,"RK":45,"PUR":94,"KT":23,"AT":99,"PET":33}
    return s
