try:
    s1=input("Enter first no:")
    s2=input("Enter second no:")
    a=int(s1)
    b=int(s2)
    c=a/b
except ZeroDivisionError as k:
    print(k)
except ValueError as v:
    print(v)
else:
    print("-"*15)
    print("Val of a:",a)
    print("Val of b:",b)
    print("-"*15)
    print("Val of c:",c)
    print("-"*15)
finally :
    print("-"*50)
    print("Thank you for using this programm")
    print("-"*50)
