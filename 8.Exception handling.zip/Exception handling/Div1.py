#Div1.py
s1=input("Enter first number:")
s2=input("Enter second number:")
a=int(s1)
b=int(s2)
c=a/b #<------ZeroDivisionError
print("Val of a:",a)
print("Val of b:",b)
print("Val of c:",c)
