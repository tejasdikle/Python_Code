try:
    s1=input("Enter 1st no:")
    s2=input("Enter 2nd no:")
    a=int(s1)
    b=int(s2)
    c=a/b

except ZeroDivisionError:
    print("Dont ente zero for denomentor")
except ValueError:
    print("Dont enter str ,symbol and alpha numeric")
else:
    
    print("Value of a=",a)
    print("Value of b=",b)
    print("Value of c=",c)
finally:
    print("="*50)
    print("Thank you for using this progrmm")
    print("="*50)
