try:
    s1=input("Enter first no:")
    s2=input("Enter second no:")
    a=int(s1)
    b=int(s2)
    c=a/b
    print("Value of c:",c)
except ZeroDivisionError:
    print("Don't enter zero for den..")
except ValueError:
    print("Don't enter strs and symbol")
