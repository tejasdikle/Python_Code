import calendar
try:
    s1=input("Enter first no:")
    s2=input("Enter second no:")
    a=int(s1)
    b=int(s2)
    c=a/b
    s="Python"
    print(s[::1])
except ZeroDivisionError as k:
    print(k)
except ValueError as v:
    print(v)
except IndexError:
    print("String index not matching")
except:
    print("Something went wrong")

else:
    print("-"*15)
    #time.sleep(2)
    print("Val of a:",a)
    print("Val of b:",b)
    print("-"*15)
    #time.sleep(2)
    print("Val of c:",c)
    print("-"*15)
    
    #print(calendar.month(2022,4))
finally :
    print("-"*50)
    print("Thank you for using this programm")
    print("-"*50)
