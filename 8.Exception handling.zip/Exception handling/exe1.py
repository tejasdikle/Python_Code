#exe1.py
a=10
b=2
c=a/b
print("Value of a:",a)
print("Value of b:",b)
print("Value of c:",c)
