try:
    s1=input("Enter 1st no:")
    s2=input("Enter 2nd no:")
    a=int(s1)
    b=int(s2)
    c=a/b
    print("Value of a=",a)
    print("Value of b=",b)
    print("Value of c=",c)
except:
    print("Oops something is wrong")
