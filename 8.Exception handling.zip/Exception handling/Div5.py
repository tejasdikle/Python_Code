try:
    s1=int(input("Enter the first no:"))
    s2=int(input("Enter the second no:"))
    a=s1
    b=s2
    c=s1/s2
 
except ZeroDivisionError or ValueError:
    print("Dont enter zero for denomntor")
    print("Dont enter str and alpha numeric")
else:
    print("Val of c:",c)
