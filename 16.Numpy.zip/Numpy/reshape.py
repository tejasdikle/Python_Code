import numpy as np
lst=[10,20,30,40,50,60]
a=np.array(lst)
print(a)
d=a.reshape(2,3)
print(d)
s=d[1,2]
print(s)
