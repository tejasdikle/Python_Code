import numpy as np
w=np.arange(12)
d=np.arange(1,12)
print(w)
print("******************************")
a=w.reshape(2,6)
b=w.reshape(2,6)
print(a)
print("******************************")
print(b)
print("******************************")
z=a+b
print(z)
print("******************************")
