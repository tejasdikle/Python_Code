import numpy as np
obj=["tr","er","sd","df"]
a=np.array(obj)
print(a)
print("=========================")
d=a.reshape(2,2)
print(d)


