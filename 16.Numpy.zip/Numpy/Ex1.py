import numpy as np
lst=[1,2,3,4,5,6,7,8,9,2,3,1,3,4,6,5]
d=np.array(lst)
print(d)
print("="*50)

c=d.reshape(4,4) #here lst will become matrix
print(c)
print("="*50)

f=c.T #here row will become column
print(f)
print("="*50)

g=d.reshape(4,2,2) #here get 4 times matrises
print(g)
print("="*50)
