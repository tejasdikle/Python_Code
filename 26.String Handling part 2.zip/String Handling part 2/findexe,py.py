line=input("Enter a line of text:")
print("Given text line:{}".format(line))
for ch in line:
    print("Character:{}".format(ch,line.find(ch)))
