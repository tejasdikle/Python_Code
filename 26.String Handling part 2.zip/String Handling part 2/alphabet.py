#alphaet.py
line=input("Enter line of text:")
vs=[]
cs=[]
ds=[]
ss=[]
for ch in line:
    if ch in["A","E","I","O","U","a","e","i","o","u"]:
        vs.append(ch)
    elif(ch not in ["A","E","I","O","U","a","e","i","o","u"] and ch.isalpha()):
        cs.append(ch)
    elif(ch.isdigit()):
        ds.append(ch)
    else:
        ss.append(ch)
else:
    print("="*50)
    print("Given line:{}".format(line))
    print("Vowels list:{}".format(vs))
    print("Character list:{}".format(cs))
    print("Digit list:{}".format(ds))
    print("special symbol:{}".format(ss))
    print("="*50)
