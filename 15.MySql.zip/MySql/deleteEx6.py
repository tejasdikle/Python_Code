import mysql.connector as db
def deletestudentrecord():
    try:
        while(True):
            con=db.connect(host='localhost',user='root',passwd='Tejas@2001',database='hyd')
            cur=con.cursor()
            
            sno=int(input("Enter sno no:"))
            cur.execute("delete from student where sno=%d"%sno)
            con.commit()
            print("="*50)
            if(cur.rowcount>0):
                print("Student record remove successfully")
            else:
                print("Student record does not exits")
    except mysql.connector.DatabaseError as db:
        print("Problem in DB",db)
deletestudentrecord()
