import mysql.connector as db
con=db.connect(host="localhost",user="root",passwd="Tejas@2001",database="hyd")
cur=con.cursor()
db="insert into student values(161,'Teja',26.90)"
cur.execute(db)
con.commit()
print("{} Record Inserted".format(cur.rowcount))
