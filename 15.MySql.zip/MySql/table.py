import mysql.connector as fp
con=fp.connect(host='localhost',user='root',passwd='Tejas@2001',database='amd')
cur=con.cursor()
id="create  Table masterS(sno int ,sname varchar(10) not null ,cm real not null,cppm real not null,pytm real not null,HTML real not null,JAVAM real not null)"
cur.execute(id)
print("Student Table create successfully")
