import mysql.connector as db
con=db.connect(host="localhost",user="root",passwd="Tejas@2001")
cur=con.cursor()
id="create database hyd"
cur.execute(id)
print("DB create successfully")
