import mysql.connector as fp
def deletestudentrecord():
    while(True):
        con=fp.connect(host='localhost',user='root',passwd='Tejas@2001',database='amd')
        cur=con.cursor()
        sno=int(input("Enter student number:"))
        sname=input("Enter student name:")
        id="update masters set sname ='%s',marks=marks+marks*10/100 where sno=%d"
        cur.execute(id%(sname,sno))
        con.commit()
        if(cur.rowcount>0):    
            print("{} record update from masters table successfully".format(cur.rowcount))
        else:
            print("File does not exist")
        print("="*50)
        ch=input("Do u want to delete another one record(y/n)")
        if(ch=="n"):
            print("\nThank u for using this programm")
            break
        print("="*50)
deletestudentrecord()
