import mysql.connector as fp
con=fp.connect(host='localhost',user='root',passwd='Tejas@2001')
cur=con.cursor()
id="create database amd"
cur.execute(id)
print("Database create successfully")
