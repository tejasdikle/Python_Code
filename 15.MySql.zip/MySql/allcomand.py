import mysql.connector as fp
import sys
con=fp.connect(host='localhost',user='root',passwd='Tejas@2001',database='amd')
cur=con.cursor()
cur.execute("select * from masters %s"%input("Enter table name:"))
recs=cur.fetchall()
for col in [entry[0] for entry in cur.description]:
    print("{}".format(col),end="\t")
print()
print("="*60)
for rec in recs:
    for val in rec:
        print("{}".format(val),end="\t")
    print()
   
print("="*60)
print("Table Operation")
print("="*60)
print("\t1.insert")
print("\t2.update")
print("\t3.delete")
print("\t4.show updated data")
print("\t5.exit")
print("="*60)
while(True):
    ch=int(input("Enter ur choice for next operation:\n"))
    print("="*60)
    match (ch):
        
        case 1:
            id="insert into masters values(121,'kraj',23,13,23,62,61)"
            cur.execute(id)
            con.commit()
            print("Data insert successfully")
            print("="*60)
        case 2:
            sno=int(input("Enter student number:"))
            sname=input("Enter student name for updation:")
            id="update masters set sname='%s',cm=cm+cm*10/100,cppm=cppm+cppm*20/100,pytm=pytm+pytm*10/100,HTML=HTML+HTML*10/100,JAVAM=JAVAM+JAVAM*10/100 where sno=%d"
            cur.execute(id%(sname,sno))
            con.commit()
            print("Data update successfully")
            print("="*60)
        case 3:
                sno=int(input("Enter student number:"))
                cur.execute("delete from masters where sno=%d"%sno)
                con.commit()
                print("Data delete successfully")
                print("="*60)
        case 4:
            cur.execute("select * from masters %s"%input("Enter table name:"))
            recs=cur.fetchall()
            for col in [entry[0] for entry in cur.description]:
                print("{}".format(col),end="\t")
            print()
            print("="*60)
            for rec in recs:
                for val in rec:
                    print("{}".format(val),end="\t")
                print()
            print("="*60)
        case _:
            sys.exit()
                
               
           


