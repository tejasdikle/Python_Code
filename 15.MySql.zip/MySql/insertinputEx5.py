import mysql.connector as db
while(True):
    con=db.connect(host='localhost',user='root',passwd='Tejas@2001',database='hyd')
    cur=con.cursor()
    #accept data
    sno=int(input("Enter student number:"))
    sname=input("Enter student name:")
    marks=float(input("Enter student marks:"))

    #insert record on table \
    mc="insert into student values(%d,'%s',%f)"
    cur.execute(mc%(sno,sname,marks))
    con.commit()
    #(OR)
    #cur.execute("insert into student values(%d,'%s',%f"),%(sno,sname,marks))
    print("="*50)
    print("{} record save".format(cur.rowcount))
    print("="*50)
    ch=input("You want to insert another record(Y/N)")
    if(ch.lower()=='N'):
        print("Thank you for using programm")
        break
    else:
        print("="*50)
        
