import mysql.connector as mc
try:
    con=mc.connect(host="localhost",user="root",passwd="Tejas@2001")
    print("Type of con=",type(con))
    print("Python program Connected successfully from MySQL DB")
except mysql.connector.DatabaseError as db:
    print("Problem in database",db)
