import mysql.connector as fp
con=fp.connect(host='localhost',user='root',passwd='Tejas@2001',database='amd')
cur=con.cursor()
cur.execute("select * from %s"%input("Enter table name:"))
records=cur.fetchmany(4)
print("="*50)
for col in[entry[0] for entry in cur.description]:
    print("{}".format(col),end="\t")
print()
print("="*50)
#for record in records:
for val in records:
    print("{}".format(val),end="\t\n")
print()
print("="*50)
    
