import mysql.connector as fp
con=fp.connect(host='localhost',user='root',passwd='Tejas@2001',database='amd')
cur=con.cursor()
id="insert into student values(1089,'baii',40.45)"
cur.execute(id)
con.commit()
print("Insert  Student values Table create successfully")
