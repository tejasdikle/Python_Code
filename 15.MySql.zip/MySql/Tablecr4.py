import mysql.connector as db

con=db.connect(host='localhost',user='root',passwd='Tejas@2001',database='hyd')
cur=con.cursor()
    #insert record on table \
mc="insert into student values(11,'TR',90.23)"
cur.execute(mc)
con.commit()
print("{} record save".format(cur.rowcount))
