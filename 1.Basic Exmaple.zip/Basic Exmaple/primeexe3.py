#primeexe2.py
n=int(input("Enter a number:"))
if(n<=1):
    print("{} is invalid input".format(n))
else:
    result="PRIME"
    for i in range (2,n):
        if(n%i==0):
            result="NOTPRIME"
            break
    if(result=="NOTPRIME"):
        print("{} is not prime".format(n))
    else:
        print("{} is  prime".format(n))
           
