n=int(input("Enter a number :"))
if (n<=0):
    print('{} invalid number'.format(n))
else:
    i=1
    while(i<=n):
        print("\t{},\t{},\t{}".format(i,i*i,i**i))
        i=i+1
          
        
