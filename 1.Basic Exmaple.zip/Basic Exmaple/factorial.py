n=int(input("Enter a number :"))
if(n<=0):
    print("{} Invalid Number ".format(n))
else:
    f=1
    while(n>0):
        f=f*n
        n=n-1
    else:
        print("Factorial={}".format(f))
