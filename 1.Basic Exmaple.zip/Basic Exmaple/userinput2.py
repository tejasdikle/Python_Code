n=int(input("Enter how many mul table u want:"))
if (n<=0):
    print("{} Invalid Number ".format(n))
else:
    lst=[]
    for i in range(1,n+1):
        x=int(input("Enter {} value:".format(i)))
        lst.append(x)
    else:
        print("="*50)
        print("Given List :{} ".format(lst))
        print("="*50)
        for n in lst:
            if (n<=0):
                print("{} Invalid Input".format(n))
                print("="*50)
                
            else:
                print("Mul table for :{}".format(n))
                print("="*50)
                i=1
                while(i<=10):
                    print("{} * {} = {}".format(n,i,n*i))
                    i=i+1
                else:
                     print("="*50)
        else:
            print("="*50)
            
        
