while(True):
    age=int(input("Enter your citizen age:"))
    if(age>=18)and(age<=100):
        break
print("{} your are eligible to vote ".format(age))
