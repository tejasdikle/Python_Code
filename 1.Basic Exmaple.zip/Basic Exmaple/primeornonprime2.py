#primeornonprime.py
n=int(input("Enter how many number u want to write it:"))
if(n<=0):
    print("{} Ivalid Input".format(n))
else:
    lst=[]#empty list
    for i in range (1,n+1):
        val=int(input("Enter {} value :".format(i)))
        if (val<0):
            print("{} It can't added in list".format(val))
        else:
            lst.append(val)
    else:
        print("*"*50)
        print("Content in list={}".format(lst))
        print("*"*50)
        if(len(lst)==0):
            print("Nothing is there to prepare the list")
            print("*"*50)
        else:
            #decide the list prime or not
            pmlist=[]
            npmlist=[]
            for n in lst:
                result="Prime"
                for i in range(2,n):
                    if(n%i==0):
                        result="Not Prime"
                        break
                if(result=="Prime"):
                    pmlist.append(n)
                else:
                    npmlist.append(n)
            else:
                print("="*50)
                print("prime list={}".format(pmlist))
                print("="*50)
                print("Non-prime list={}".format(npmlist))
                print("="*50)   
