#avg.py
n=int(input("Enter a number what u want for sum and avarage:"))
if(n<=0):
    print("[] invalid Input".format(n))
else:
    lst=list()
    for i in range(1,n+1):
        val=int(input("Enter {} value :".format(i)))
        lst.append(val)
    else:
        print("="*50)
        print("Content in {}".format(lst))
        s=0
        for val in lst:
            s=s+val
        else:
            print("="*50)
            print("sum={}".format(s))
            print("Average={}".format(s/len(lst)))
        
       
        
print("="*50)
