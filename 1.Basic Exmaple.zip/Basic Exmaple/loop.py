#forloop.py
n=int(input("Enter line of text:"))
vow=0
for ch in line:
    if ch in line(['a','e','i','o','u','A','E','I','O','U']):
   
    
