n=int(input("Enter a number:"))
if(n<=0):
    print("{} invalid Number ".format(n))
else:
    print("="*50)
    print("Mul of :{}".format(n))
    print("="*50)
    for i in range (1,11):
        print("\t{}*{}={}".format(n,i,n*i))
    else:
        print("="*50)
