n=int(input("Enter how many mul table you want:"))
if(n<=0):
      print("{} invalid input".format(n))
else:
    i=1
    while(i<=n):
        print("="*50)
        print("Mul table of {}".format(i))
        print("="*50)
        for j in range (1,11):
            print("{}*{}={}".format(i,j,i*j))
            
        else:
           
            i=i+1
    else:
        print("="*50)

