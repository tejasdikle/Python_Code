n=int(input("Enter a number :"))
if(n<=0):
    print("{} invalid number".format(n))
else:
    print("Number within {}".format(n))
    i=1
    while(i<=n):
        print("\t{}".format(i))
        i=i+1
        
