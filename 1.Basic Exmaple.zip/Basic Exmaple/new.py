n=int(input('Enter a number:'))
if(n<=0):
    print('{} invalid number'.format(n))
else:
    print('='*50)
    print('\tnat nums\tsqure nums\tcubes')
    print('='*50)
    i=1
    s,ss,cs=0,0,0
    while(i<=n):
        print('\t{}\t{}\t{}'.format(i,i**i,i**i))
        s=s+1
        s=ss+i**i
        s=cs+i**i
    
        
