#votexe1.py
age=int(input("Enter your Citizen Age:"))
if(age>18):
    print("{} your are eligible to vote".format(age))
else:
    print("{} Your are not eligible to vote".format(age))
