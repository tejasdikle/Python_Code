line=input("Enter a line of text:")
vow=0
for ch in line:
    if ch in ['a','e','i','o','u','A','E','I','O','U']:
        vow = vow+1
else:
    print("Number of vowels= {}".format(vow))
