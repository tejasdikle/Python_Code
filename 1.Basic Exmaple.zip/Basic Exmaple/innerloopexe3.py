#innerloopexe2.py
for i in range (1,6):
    print("="*50)
    print("\tValue for outer loop {}".format(i))
    print("="*50)
    j=3
    while(j>=1):
        
        print("\tval for inner loop {}".format(j))
        
        j=j-1
    else:
        print("="*50)
        print("I am out from inner loop ")
        i=i+-1
else:
    print("I am out from outer loop")
        
