#break2.py
lst=[10,20,30,40,50,60,70,80,90]
for val in lst:
    if (val==60):
        break
    else:
        print("\t{}".format(val))
else:
    print("I am from else block")
print("Other statement in programm")
        
