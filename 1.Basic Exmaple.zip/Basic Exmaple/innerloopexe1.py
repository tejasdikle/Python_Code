#innerloopexe1.py
for i in range (1,6):
    print("="*50)
    print("\tval of i in outer range{}".format(i))
    print("="*50)
    for j in range (1,4):
        print("\tvalue of j inner range {}".format(j))
        
else:
    print("="*50)
    print("I am out from inner loop ")
