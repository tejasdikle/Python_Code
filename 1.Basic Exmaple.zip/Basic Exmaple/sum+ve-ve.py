#sumpositivexe1.py
n=int(input("Enter a number u want to have:"))
if (n<=0):
    print("{} invalid input".format(n))
else:
    lst=list()
    for i in range(1,n+1):
        val=int(input("Enter {} value:".format(i)))
        lst.append(val)
    else:
        print("="*50)
        print("Content in list ={}".format(lst))
        print("="*50)
        ps=0
        pslist=list()
        for val in lst:
            if (val<=0):
                continue
            else:
                pslist.append(val)
                ps=ps+val
        else:
            print("sum of positive number :{}={}".format(pslist,ps))
            print("="*50)
            ns=0
            nslist=list()
            for val in lst:
                if(val>=0):
                    continue
                else:
                    nslist.append(val)
                    ns=ns+val
            else:
                print("sum of negetive number:{}={}".format(nslist,ns))
                
                    
