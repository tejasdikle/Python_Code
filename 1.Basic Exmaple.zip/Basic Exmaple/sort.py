#sort.py
n=int(input("Enter how many name u want to sort:"))
if(n<=0):
    print("{} is invalid".format(n))
else:
    
    lst=list()
    for i in range (1,n+1):
        val=str(input("Enter {} name:".format(i)))
        lst.append(val)
    else:
        print("Original list:".format(lst))
        for name in lst:
            print("\t{}".format(lst))
        else:
            lst.sort()
            print("Name is asending Order:")
            for name in lst:
                print("\t{}".format(name))
            else:
                lst.sort(reverse=True)
                print("Name is descending  order :")
                for name in lst:
                    print("\t{}".format(name))
        
