#factorex.py
n=int(input("Enter a Number:"))
if(n<=0):
    print("{} invalid Number".format(n))
else:
    s=0
    print("Given Number:{}".format(n))
    print("Factor:")
    for i in range(1,n//2+1):
        if(n%i==0):
            print("\t{}".format(i),end="")
            s=s+1
        else:
            if(s==n):
                print("{} is perfect".format(n))
            else:
                print("{} is not perfect".format(n))
