#innerloopexe4.py
i=5
while(i>=1):
    print("val of outer loop {}".format(i))
    print("="*50)
    j=3
    while(j>=1):
        print("val of inner loop {} ".format(j))
        j=j-1
    else:
        print("INNER LOOP OUT")
        i=i-1
else:
    print("="*50)
    print("OUTER  LOOP OUT")
