#innerloopexe2.py
i=1
while(i<=5):
    print("="*50)
    print("\tvalue for outer for loop {}".format(i))
    print("="*50)
    j=1
    while(j<=3):
        print("\tValue for inner for loop {}".format(j))
        j+=1
    else:
        print("I am out from inner for loop")
        i+=1
else:
    print("="*50)
    print("I am out for outer for loop")
    
