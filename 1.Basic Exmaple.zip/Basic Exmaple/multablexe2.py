#multablexe2.py
print("----------------------------------------------")
n=int(input("Enter a number for multiplication table:"))
print("------------------********----------------------")
if (n<=0):
    print("{} Invalid Number".format(n))
else:
    print("="*50)
    for i in range(1,n+1):
        print("Multiplication table for :{}".format(i))
        print("="*50)
        for j in range(1,11):
            print("\t{}*{}={}".format(i,j,i*j))
            
        else:
            print("="*50)
            i=i+1
            
    else:
        print("T  H  A  N  K  Y  O  U")
