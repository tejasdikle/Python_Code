#randommultable.py
list=[2,3,7,-5,69,-4,98]
for n in list:
    if(n<=0):
        print("{} Inavlid Number".format(n))
        print("="*50)
    else:
        print("Mul table for:{}".format(n))
        print("="*50)
        i=1
        while(i<=10):
            print("{} * {} ={}".format(n,i,n*i))
            i=i+1
        else:
            print("="*50)

