#primelist.py
n=int(input("Enter hoW many number u want:"))
if (n<=0):
    print("{} Invalid input".format(n))
else:
    lst=[]#empty list
    for i in range (1,n+1):
        val=int(input("Enter {} value:".format(i)))
        if(val<0):
            print("{} invalid number it cant be added in list".format(val))
        else:
            lst.append(val)
    else:
        print("="*50)
        print("Content in list={}".format(lst))
        print("="*50)
        if(len(lst)==0):
            print("Nothing is there to prepare the list")
        else:
            pmlist=[]
            nplist=[]
            for n in lst:
                Result="Prime"
                for i in range (2,n):
                    if (n%i==0):
                        result="Not prime"
                        break
                if(result=="Prime"):
                    pmlist.append(n)
                else:
                    nplist.append(n)
            else:
                print("="*50)
                    
