n=int(input("enter a number:"))
if (n<=0):
    print("[} invalid input".format(n))
else:
    print("Given number ={}".format(n))
    s=0
    while(n>0):
        d=n%10
        s=s+d
        n=n//10
    else :
        print("sum of digit ={}".format(s))
