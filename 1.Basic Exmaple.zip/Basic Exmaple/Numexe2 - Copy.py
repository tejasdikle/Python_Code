n=int(input("Enter a number :"))
if (n<=0):
    print("{} invalid Number ".format(n))
else:
    print(" Number within {}".format(n))
    i=n
    while(i>=1):
        print("\t{}".format(i))
        i=i-1
        
