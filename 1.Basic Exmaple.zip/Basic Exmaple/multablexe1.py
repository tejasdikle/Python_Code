#multeblexe1.py
n=int(input('Enter a number for mul table:'))
if(n<=0):
      print('{} Is Invalid Number'.format(n))
else:
    i=1
    while(i<=n):
        print('Mul table for:{}'.format(i))
        print('='*50)
        for j in range(1,11):
            print('{} * {} = {}'.format(i,j,i*j))
        else:
            print('='*50)
            i=i+1
    else:
        print('THANK YOU FOR USE')
