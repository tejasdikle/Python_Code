#studentmarksreport.py
while(True):
    sno=int(input("Enter student number:"))
    if(sno>=100)and(sno<=200):
        print("="*50)
        break
#accept name
sname=input("Enter student name:")
print("="*50)
#marks C
while(True):
    cm=int(input("\tEnter marks in C:"))
    if(cm>=0)and(cm<=100):
        break
#marks C++
while(True):
    cppm=int(input("\tEnter marks in c++:"))
    if(cppm>=0) and (cppm<=100):
        break
#Python
while(True):
    pytm=int(input("\tEnter marks in python:"))
    if(pytm>=0)and(pytm<=100):
        break
totalmarks=cm+cppm+pytm
percent=(totalmarks/300)*100
#decide the grade 
if(cm<40)or(cppm<40)or(pytm<40):
    grade="FAIL"
    print("\tStudent Grade:{}".format(grade))

   
else:
    print("*"*50)
    print("student marks report")
    print("*"*50)
    print("\tStudent number:{}".format(sno))
    print("\tStudent name:{}".format(sname))
    print("\tStudent marks in c:{}".format(cm))
    print("\tStudent marks in c++:{}".format(cppm))
    print("\tStudent marks in python:{}".format(pytm))
    print("="*50)
    print("\tStudent total marks:{}".format(totalmarks))
    print("\tStudent percent:{}".format(percent))
    
    print("="*50)
