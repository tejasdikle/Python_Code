big=lambda a,b,c: "all are equal"  if (a==b) and (b==c) else  a if (a>b) and (a>c) else b if (b>c) and (b>a) else c if (c>a) and (c>b)else a
small=lambda a,b,c: "all are equal"  if (a==b) and (b==c) else  a if (a<b) and (a<c) else b if (b<c) and (b<a) else c if (c<a) and (c<b)else a

x,y,z=float(input("Enter first value :")),float(input("Enter second value :")),float(input("Enter third value :"))
res1=big(x,y,z)
res2=small(x,y,z)
print("biggest=",res1)
print("Smallest=",res2)
