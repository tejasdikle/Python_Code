def addop(a,b):
    c=a+b
    return c
sumop=lambda a,b: a+b
x,y=float(input("Enter first value:")),float(input("Enter first value:"))
res1=sumop(x,y)
print("="*50)
print("Sum of :",res1)
print("="*50)
res2=sumop(x,y)
print("Sum of :",res2)
