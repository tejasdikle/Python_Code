big=lambda lst: max(lst)
small=lambda obj: min(obj)

lst=[]
while (True):
    val=(input("Enter value (press 'stop' enter):"))
    if(val=="stop"):
        break
    else:
        lst.append(int(val))
if(len(lst)==0):
    print("List content zero element")
elif(len(lst)==1):
    print("both the value are same and itself is max and min")
else:
    print("Max:({})={}".format(lst,(big(lst))))
    print("Min:({})={}".format(lst,(small(lst))))
