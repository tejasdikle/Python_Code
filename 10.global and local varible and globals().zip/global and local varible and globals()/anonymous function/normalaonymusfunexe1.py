addop=lambda a,b :a+b
res=addop(100,200)
print("type of addop =",type(addop))
print("Sum of :",res)
