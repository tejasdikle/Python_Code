import sys
sys.path.append("C:\Users\Tejas Dhikale\Documents\python course\package")
print("Teacher name:{}".format(tname))
print("Teacher Subject:{}".format(subject))
