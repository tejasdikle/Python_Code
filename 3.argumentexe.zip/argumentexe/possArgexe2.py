#possAgrexe2.py
def showinfo(stno,stname,marks):
    print("\t{}\t{}\t{}".format(stno,stname,marks))
#main programm
print("="*50)
print("\tstno\tstname\tmarks")
print("="*50)
showinfo(10,'Rossum',56)

print("="*50)
