#possArguexe3.py
def showinfo(sno,sname ,marks,crs):
    print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))

#main programm
print("="*50)
print("\tsno\tsname\tmarks\tcrs")
print("="*50)
showinfo(10,'RS',33.03,'PYTHON')
showinfo(20,'TS',49,'PYTHON')


print("="*50)
