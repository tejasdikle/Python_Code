def computer(x,y,z):
    k=x+y+z
    print("Result=",k)#x,y and z are called formal parmeter
    


#main program
a=10
b=20
c=30
computer(a,b,c)#Function call ---a,band c are called argument
computer(100,200,300)#function call 100,200,300 argument values
computer(0.22,30,0.34)
