#defaultArgexe3.py
import time
def javacourse(sno,sname,marks,crs='java'):
    print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))
    
def pythoncourse(sno,sname,marks,crs='python'):
    print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))
    
def ccourse(sno,sname,marks,crs='c'):
    print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))

#main programm
print("="*50)
print("\tsno\tsname\tmarks\tcrs")
print("="*50)
javacourse(10,'RS',30)
javacourse(20,'FS',30.34)
pythoncourse(30,'AS',34)
pythoncourse(40,'WS',43)
javacourse(50,'ES',50)
ccourse(60,'SS',70)
ccourse(70,'TS',100.39)
print("="*50)
