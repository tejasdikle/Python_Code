def computer(x,y,z):
    k=x+y+z
    print("Result=",k)
    


#main program
a=10
b=20
c=30
computer(a,b,c)
