#defaultArgexe2.py
def disp(a=1,b=2,c=3):
    print("\t{}\t{}\t{}".format(a,b,c))
#main programm
print("="*50)
print("\ta\tb\tc")
print("="*50)
disp()
disp(10)
disp(10,20)
disp(10,20,30)
print("="*50)
