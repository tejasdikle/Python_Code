import csv
fn=['Tno','Tname','Tsub','Tsch']
rows=[['11','TR','MATH','SGS'],
      ['22','DF','SCI','MKL'],
      ['33','RE','SOCI','WDF'],
      ['44','FG','HIN','SDF']]
filename='university_records.csv'
with open(filename,'w')as fp:
    fd=csv.writer(fp)
    fd.writerow(fn)
    fd.writerows(rows)
    print("csv file created successfully")
