try:
    with open("stud.csv","r")as fp:
        tr=fp.read()
        print(tr)
except FileNotFoundError:
    print("File does not eist")
