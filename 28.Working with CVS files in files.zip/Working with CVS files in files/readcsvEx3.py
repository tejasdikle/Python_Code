import csv
with open("stud.cvs","r")as fp:
    df=csv.reader(fp)
    for fd in df:
        for val in fd:
            print("{}".format(val),end="\t")#REMOVE COMMA FROM OTPUT DATA
        print()
  
