import csv
with open('college_records.csv','r')as fp:
    fd=csv.DictReader(fp)
    for d in fd:
        for m,v in d.items():
            print("{}---->{}".format(m,v),end="\t")
        print()
