import pandas as kvr
fd=kvr.read_csv("C:\\Users\\Tejas Dhikale\\Documents\\python course\\Emp_records.csv")
print(fd)
