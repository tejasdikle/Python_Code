import csv
fn=['Eno','Ename','Esal','Cmp']
rows=[['TEJAS','COE','1','8'],
           ['RAHUL','ME','2','7'],
           ['NANA','CS','4','7'],
           ['BAA','IT','2','7'],
           ['MINA','ENTC','3','9.9']]
filename="Emp_records.csv"
with open(filename,'w')as fp:
    fd=csv.writer(fp)
    fd.writerow(fn)
    fd.writerows(rows)
    print("csv file created successfully")
