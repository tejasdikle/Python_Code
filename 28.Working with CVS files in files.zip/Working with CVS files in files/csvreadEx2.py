import csv
with open("student_records.csv",'r')as fp:
    fd=csv.reader(fp)
    for mk in fd:
        for val in mk:
            print("{}".format(val),end='\t')
        print()
