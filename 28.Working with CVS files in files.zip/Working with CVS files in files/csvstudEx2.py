import csv
fn=['sno','sname','smarks']
row=[['1','Tejas','89'],
    ['2','Rahul','56'],
    ['3','vijay','99']]
filename="student_records.csv"
with open(filename,'w')as fp:
    fd=csv.writer(fp)
    fd.writerow(fn)
    fd.writerows(row)
    print("csv file created successfully")
