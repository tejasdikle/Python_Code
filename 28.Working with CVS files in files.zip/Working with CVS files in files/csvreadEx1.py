import csv
try:
    with open("student_records.csv","r")as fp:
        fd=csv.reader(fp)
        for ad in fd:
            for val in ad:
                print("{}".format(val),end="\t")
            print()
except FileNotFoundError:
    print("File does not exsit")
