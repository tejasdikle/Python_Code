import csv
dict=[{'branch':'me','cgpa':'8','year':'4','name':'Nikhil'},
      {'branch':'me','cgpa':'8','year':'4','name':'tejas'},
      {'branch':'me','cgpa':'8','year':'4','name':'rahul'},
      {'branch':'me','cgpa':'8','year':'4','name':'nana'},
      {'branch':'me','cgpa':'8','year':'4','name':'kaka'},
      {'branch':'me','cgpa':'8','year':'4','name':'baba'}]
fn=['name','cgpa','year','branch']
filename='college_records.csv'
with open(filename,'w')as fp:
    dw=csv.DictWriter(fp,fieldnames=fn)
    dw.writeheader()
    dw.writerows(dict)
    
   
    print("dict data filecreates successfully")
   
