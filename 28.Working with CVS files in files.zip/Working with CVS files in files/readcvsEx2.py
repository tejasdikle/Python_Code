import csv
try:
    with open("stud.cvs","r")as fp:
        cr=csv.reader(fp)
        print("Type of cr=",type(cr))
        for mk in cr:
            print("{}".format(mk))# COMMA IS IN THE OUTPUT DATA
        print()
except FileNotFoundError:
    print("File does not exist:")
 
