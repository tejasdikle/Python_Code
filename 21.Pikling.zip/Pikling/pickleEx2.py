import pickle
def reademprecord():
    with open("emprec.data","rb") as fp:
        print("="*50)
        print("\tEno\tEname\tEsal")
        print("="*50)

        while(True):
            try:
                fd=pickle.load(fp)
                for val in fd:
                    print("\t{}".format(val),end="")
                print()
            except EOFError:
                print("="*50)
                break
                
                
reademprecord()

