import pickle
def saveemprecords():
    nor=int(input("Enter how many record u have:"))
    if(nor<=0):
        print("Invalid number of records")
    else:
        
        with open("emprec.data","ab")as fp:
            print("="*50)
            for i in range(1,nor+1):
                print("Enter {} employed record".format(i))
                print("="*50)

                #accept employed data
                eno=int(input("Enter the employes No:"))
                ename=input("Enter employed name:")
                esal=float(input("Enter employed salary:"))
                #aappend emp list
                lst=[]
                lst.append(eno)
                lst.append(ename)
                lst.append(esal)
                
                pickle.dump(lst,fp)
                print("="*50)
                print("Data save successfully")
                print("="*50)
saveemprecords()
                
                
                
            
