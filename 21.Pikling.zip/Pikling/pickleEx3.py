import pickle
def saveemprecords():
        with open("addre.data","ab")as fp:
            while(True):
                print("="*50)
                eno=int(input("Enter the emp no:"))
                ename=input("Enter the emp name:")
                esal=int(input("Enter the emp sal"))
                print("="*50)
                lst=[]
                lst.append(eno)
                lst.append(ename)
                lst.append(esal)
                obj=pickle.dump(lst,fp)
                print("="*40)
                print("Data save successfully")
                print("="*40)
                ch=input("You want to insert another record(yes/no):")
                if(ch=="no"):            
                    print("Thank you for using this programm")                
                    print("Invalid input")
saveemprecords()        
