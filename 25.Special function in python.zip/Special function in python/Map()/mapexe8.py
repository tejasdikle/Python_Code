print("Enter the first list value sepreted by space:")
lst1=[int(val)for val in input().split()]
print("Enter the second list value sepreted by space:")
lst2=[int(val)for val in input().split()]
print("="*50)
print("\tList-1\tList-2\taddition list-3")
print("="*50)
lst3=map(lambda a,b:a+b,lst1,lst2)
for l1,l2,l3 in zip (lst1,lst2,lst3):
    print("\t{}\t{}\t{}".format(l1,l2,l3))
print("="*50)
