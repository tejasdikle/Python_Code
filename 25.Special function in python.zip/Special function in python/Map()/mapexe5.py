print("Enter list the value")
lst=[int(val)for val in input().split()]
