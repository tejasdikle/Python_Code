def hike(sal):
    sal=sal+sal*2
    return sal
#main programm
print("Enter the old salaries of employed :")
oldsal=[float(sal) for sal in input().split()]
print("Enter company name :")
clist=[str(cname)for cname in input().split(",")]
print("="*50)
print("\told salaries\tNew salaries\tcompany name")
print("="*50)
newsal=map(hike,oldsal)
for ols,nls,cls in zip(oldsal,newsal,clist):
    print("\t{}\t\t{}\t\t{}".format(ols,nls,cls))
print("="*50)
