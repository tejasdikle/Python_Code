lst1=[10,20,30,40,50,60]
lst2=[100,200,300,400,500,600]
lst3=map(lambda a,b:a+b,lst1,lst2)
print("="*50)
print("\tlist-1\t\tlist-2\t\taddition list")
print("="*50)
for l1,l2,l3 in zip (lst1,lst2,lst3):
    print("\t{}  +\t\t{}  \t=\t{}".format(l1,l2,l3))
print("="*50)
