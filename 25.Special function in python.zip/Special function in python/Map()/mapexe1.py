def hike(sal):
    sal=sal+sal*0.2
    return sal
#main programm
print("Enter old salary of employed ")
oldsal=[float(sal) for sal in input().split()]
print("Company name sepreted by comm")
clist=[str(cname) for cname in input().split(",")]
obj=list(map(hike,oldsal))
print("="*50)
print("\told sal\tCname\tNew sal")
print("="*50)
for ols,cls,ncl in zip (oldsal,obj,clist):
    print("\t{}\t{}\t{}".format(ols,ncl,cls))
