hike=lambda sal:sal+sal*0.2
#main programm
print("Enter the old salaries:")
oldsal=[int(sal)for sal in input().split()]
print("Enter the company name:")
clist=[str(cname)for cname in input().split()]
newsal=list(map(hike,oldsal))
print("="*50)
print("\toldsal\t\tnewsal\t\tcname")
print("="*50)
for ols,nls,cls in zip (oldsal,newsal,clist):
    print("\t{}\t\t{}\t\t{}".format(ols,nls,cls))
