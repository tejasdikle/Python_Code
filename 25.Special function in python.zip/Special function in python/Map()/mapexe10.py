#AFTER 10% SALARIES HIKE
print("Enter salaries list of employed:")
salist=[int(sal)for sal in input().split()]
less5000=list(filter(lambda sal:sal>=0 and sal<=5000 ,salist))
newsal5000=map(lambda sal:sal+sal*0.2,less5000)
print("="*50)
print("\tLESS 5000 SALARIES\tNEW UPATED SALRIES")
print("="*50)
for ol,nl in zip (less5000,newsal5000):
    print("\t{}\t\t\t{}".format(ol,nl))
#AFTER SALARIES HIKE 20%
more5000=list(filter(lambda sal:sal>=5000 ,salist))
newmore5000=list(map(lambda sal:sal+sal*1,more5000))
print("="*50)
print("\tMORE 5000 SALARIES\tNEW UPATED SALRIESE")
print("="*50)
for ol,nl in zip (more5000,newmore5000):
    print("\t{}\t\t\t{}".format(ol,nl))
print("="*50)
