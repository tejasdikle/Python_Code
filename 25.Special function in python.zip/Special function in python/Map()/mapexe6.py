print("Enter the list value:")
lst=[int(val)for val in input().split()]
sqrlist=map(lambda val:val**2,lst)
cublist=map(lambda val:val**3,lst)
print("="*50)
print("   Orignal value    Squre value       Sq.value")
print("="*50)
for ov,sqv,curv in zip (lst,sqrlist,cublist):
    print("\t{}\t\t{}\t\t{}".format(ov,sqv,round(curv,1)))
print("="*50)
