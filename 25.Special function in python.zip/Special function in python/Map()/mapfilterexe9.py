print("Enter the list of salaries of employed:")
salist=[int(val)for val in input().split()]
less5000=list(filter(lambda sal:sal>=0 and sal<=5000,salist))
more5000=list(map(lambda sal:sal+sal*0.1,less5000))
print("="*50)
print("Salaries less 5000\tNew salaries after hike")
print("="*50)
for ls,ms in zip (less5000,more5000):
    print("\t{}\t\t{}".format(ls,round(ms,4)))
print("="*50)

more5000=list(filter(lambda sal:sal>5000 and sal<=10000,salist))
newmore5000=list(map(lambda sal:sal+sal*0.2,more5000))
print("="*50)
print("Salaries more 5000\tNew salaries after hike")
print("="*50)
for ls,ms in zip (more5000,newmore5000):
    print("\t{}\t\t{}".format(ls,round(ms,4)))
print("="*50)

more10000=list(filter(lambda sal:sal>=10000,salist))
newmore10000=list(map(lambda sal:sal+sal*0.2,more10000))
print("="*50)
print("Salaries more 10000\tNew salaries after hike")
print("="*50)
for ls,ms in zip (more10000,newmore10000):
    print("\t{}\t\t{}".format(ls,round(ms,4)))
print("="*50)
