print("Enter the old salaries :")
oldsal=[int(sal)for sal in input().split()]
incr=float(input("Enter the percentage of increament:"))
print("Enter the company name:")
clist=[str(cname) for cname in input().split()]
newsal=map(lambda sal:sal+sal*incr/100,oldsal)
print("="*50)
print("\told sal\t\tnew sal\t\t c name")
print("="*50)
for ols,nls,cls in zip (oldsal,newsal,clist):
    print("\t{}\t\t{}\t\t{}".format(ols,nls,cls))
print("="*50)
