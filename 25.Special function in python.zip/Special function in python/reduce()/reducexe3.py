import functools
print("Enter the list of value :")
lst=[int(val) for val in input().split()]
print("="*50)
print("Given list :",lst)
print("="*50)
sum=functools.reduce(lambda a,b:a+b,lst)
avg=functools.reduce(lambda a,b: sum/len(lst),lst)
print("Sum :",sum)
print("="*50)
print("Avarage :",avg)
print("="*50)
