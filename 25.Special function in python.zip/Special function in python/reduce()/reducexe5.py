"""def hike(sal):
    sal=sal+sal*0.2
    return sal"""
print("Enter the old salary of employed:")
lst=[float(val) for val in input().split()]
sal=list(map(lambda sal:sal+sal*0.2,lst))
print("Privious salary",lst)
print("Update salary:",sal)
