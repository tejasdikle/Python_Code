import functools
print("Enter list of words sepreted by comm:")
x=[str(val)for val in input().split(",")]
print(x)
print("="*50)
t=tuple(x)
print("Type of t=",type(t))
print("="*50)
print("Content in tuple ={}".format(t))
line=functools.reduce(lambda a,b:a+""+b,t)

print("Concatenated result={}".format(line))
print("="*50)
