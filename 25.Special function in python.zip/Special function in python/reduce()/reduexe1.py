import functools
print("Enter the value sepreted by space:")
lst=[int(val)for val in input().split()]
bv=functools.reduce(lambda k,v:k if k>v else v ,lst)
sv=functools.reduce(lambda k,v:k if k<v else v ,lst)
print("Biggest:",bv)
print("Smallest:",sv)
