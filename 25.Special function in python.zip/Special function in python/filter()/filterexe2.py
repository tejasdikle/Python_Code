#filterexe2.py
def positive(n):
    if(n>0):
        return True
    else:
        return False
#main programm
lst=[10,20,30,40,50,-12,-23,-34,-45-56]
res=filter(positive,lst)
obj=list(res)
print("positive list element:",obj)
