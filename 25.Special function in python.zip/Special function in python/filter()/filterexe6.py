lst=[]
while(True):
    val=input("Enter the value (press 'q'to stop)")
    if(val=="q"):
        break
    else:
        lst.append(int(val))
#main programm 
if(len(lst)==0):
    print("*"*50)
    print("There is no element in the list And one element in list is not valid ")
    print("*"*50)
elif(len(lst)==1):
    print("*"*50)
    print("There is no element in the list And one element in list is not valid ")
    print("*"*50)
else:
    evenlst=list(filter(lambda n:n%2==0,lst))
    oddlst=list(filter(lambda x:x%2!=0,lst))
    print("="*50)
    print("Content in list:",lst)
    print("="*50)
    print("Even list element:",evenlst)
    print("Odd list element :",oddlst)
    print("="*50)
