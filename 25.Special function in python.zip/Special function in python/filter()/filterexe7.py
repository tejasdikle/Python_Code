print("Enter the value sepreted by space:")
lst=[int(val)for val in input().split()]
pslist=list(filter(lambda n:n>0,lst))
nslist=list(filter(lambda x:x<0,lst))
print("="*50)
print("positive list :",pslist)
print("nagetive list :",nslist)
