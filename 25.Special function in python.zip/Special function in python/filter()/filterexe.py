positive=lambda n:n>0
nagetive=lambda x:x<0
#main programm
lst=[10,20,30,40,50,60,-10,-20,-30,-40,-50]
res1=list(filter(positive,lst))
res2=list(filter(nagetive,lst))
res1.sort()
res2.sort(reverse=True)
print("Given list:",lst)
print("="*70)

print("positive :",res1)
print("Nagetive :",res2)
print("="*50)
