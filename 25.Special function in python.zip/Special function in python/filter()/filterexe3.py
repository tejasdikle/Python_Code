#filterexe2.py
def positive(n):
    if(n>0):
        return True
    else:
        return False
def nagetive(n):
    if(n<0):
        return True
    else:
        return False
#main programm
lst=[10,20,30,40,50,-12,-23,-34,-45-56]
res1=list(filter(positive,lst))
res2=list(filter(nagetive,lst))
print("="*60)
print("Given element:",lst)
print("="*60)
print("positive list element:",res1)
print("nagetive list element:",res2)
print("="*50)
