#filterxe5.py
lst=[]
while(True):
    val=input("Enter the value (press 'q' enter)")
    if(val=='q'):
        break
    else:
        lst.append(int(val))
if(len(lst)==0):
    print("There is no element in list")
else:
    evenlist=list(filter(lambda n:n%2==0,lst))
    oddlist=list(filter(lambda x:x%2!=0,lst))
    print("="*50)
    print("Original list:",lst)
    print("="*50)
    print("Even list element:",evenlist)
    print("Odd list element:",oddlist)
    print("="*50)
