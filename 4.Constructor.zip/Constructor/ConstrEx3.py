class student:
    def __init__(self):
        self.sno=10
        self.sname="raju"

#MAIN PROGRAMM
s=student()
print("Content in s",s.__dict__)

