class student:
    def __init__(self,sno,sname):
        self.sno=sno
        self.sname=sname

#MAIN PROGRAMM
s=student(111,'khali')
s1=student(222,'nana')
print(s.__dict__)
print(s1.__dict__)
