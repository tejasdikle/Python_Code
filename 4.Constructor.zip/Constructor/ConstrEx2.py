class test:
    def __init__(self,a=1,b=2):#DEFAULT AND PARAMERTLESS CONSTRUCTOR
        self.a=a
        self.b=b
        print('='*50)
        print("Val of a=",self.a)
        print("Val of b=",self.b)
        print('='*50)
t=test()           #OBJECT CALLING
t=test(110,200)
t=test(2000)
t=test(1523,3000)
t=test(8000)
