class test:
    def __init__(self):
        self.a=10
        self.b=20
        print('='*50)
        print("Val of a=",self.a)
        print("Val of b=",self.b)
        print('='*50)

#MAIN PROGRAMM
t=test()

