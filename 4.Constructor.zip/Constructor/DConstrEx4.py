class student:
    def __init__(self,sno,sname):
        self.sno=sno
        self.sname=sname

#MAIN PROGRAMM
s=student(111,'khali')
print(s.__dict__)
