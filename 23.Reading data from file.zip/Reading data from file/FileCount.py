fn=input("Enter the file name:")
pd=open(fn,'r')
lines=pd.readlines()
print(lines)
