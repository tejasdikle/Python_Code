fn=input("Enter the file name:")
with open(fn,"r") as fp:
    nl,nw,nc=0,0,0
    lines=fp.readlines()
    for line in lines:
        print(line,end="\t")
        nl=nl+1
        nw=nw+len(line.split())
        nc=nc+len(line)
    else:
        print("\nNumber of line=",nl)
        print("Number of word=",nw)
        print("Number of character=",nc)
        
