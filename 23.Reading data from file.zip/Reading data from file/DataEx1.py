with open("tcs.data","w")as kt:
    kt.write("king kong\n")
    kt.write("ching chong\n")
    kt.write("ding dong\n")
    kt.write("ming mong\n")
    kt.write("ting tong\n")
    print("save")
