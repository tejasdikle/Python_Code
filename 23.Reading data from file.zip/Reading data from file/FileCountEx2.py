fn=input("Enter file name")
fp=open(fn,'r')
nl,nw,nc=0,0,0
lines=fp.readlines()
for line in lines:
    print(line,end="")
   
    nl=nl+1
    nw=nw+len(line.split())
    nc=nc+len(line)
else:
    print("\nlines=",(nl))
    print("Word=",(nw))
    print("chacter=",(nc))
