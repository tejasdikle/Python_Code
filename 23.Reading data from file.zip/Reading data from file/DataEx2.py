with open("addr1.data",'w')as fp:
    fp.write("jaimse gosling\n")
    fp.write("rossum\n")
    fp.write("guido\n")
    fp.write("hare Krushana")
    print("save")
     
