fn=input("Enter file name for reading data:")
try:
    with open(fn,"r")as np:
        pd=np.read()
        print("="*50)
        print(pd)
        print("="*50)
except FileNotFoundError:
    print("File dies not exist")
