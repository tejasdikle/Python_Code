try:
    with open ("tcs.data","r")as fp:
        line=fp.readlines()
        print(line)
except FileNotFoundError:
    print("File does not exist:")
