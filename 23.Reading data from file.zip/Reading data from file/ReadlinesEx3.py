fn=input("Enter file for showing data")
with open(fn,"r") as fp:
    lines=fp.readlines()
    for line in lines:
        print(line,end="")
   
          
