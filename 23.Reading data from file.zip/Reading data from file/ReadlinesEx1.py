try:
    with open("tcs.data","r")as pd:
        kd=pd.readlines()
        print(kd)
except FileNotFoundError:
    print("file does not exist")#READ ALL LINES AT A TIME
