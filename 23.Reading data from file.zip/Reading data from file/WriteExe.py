with open("cmp.csv","w")as fp:
    fp.write("empno empname salary\n")
    fp.write("  111, RK,    4.6\n")
    fp.write("  112, SK,    2.0\n")
    fp.write("  113, GK,    3.8\n")
    fp.write("  114, RH,    7.3\n")
    fp.write("  115, RV,    9.1\n")
    fp.write("  116, DK,    1.5\n")
    fp.write("  117, WK,    5.3\n")
    fp.write("  118, RJ,    2.6\n")
    print("Data save successfully")
    
    
