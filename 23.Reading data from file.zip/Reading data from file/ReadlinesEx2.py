try:
    with open("tcs.data","r")as fp:
        lines=fp.readlines()
        for line in lines:
            print(line)
except FileNotFoundError:
    print("File does not exist")
