fn=input("Enter the file name")
with open(fn,"r")as fp:
    fd=fp.read()
    print(len(fd))
    
