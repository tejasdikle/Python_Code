fn=input("Enter the source file:")
with open(fn,"r")as fp:
    fd=input("Enter denstination file:")
    with open(fd,"a") as kp:
        sd=fp.read()
        kp.write(sd)
        print("{} file rename into{} file".format(sd,kp))
        
