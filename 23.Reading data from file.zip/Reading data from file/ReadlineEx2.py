with open("tcs.data","r") as fp:
    fd=fp.readline()
    print(fd)
    fd=fp.readline()#lenthy process
    print(fd)
    fd=fp.readline()
    print(fd)
    fd=fp.readline()
    print(fd)
