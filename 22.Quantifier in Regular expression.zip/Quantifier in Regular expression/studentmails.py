import re
try:
    with open ("snm.data","r") as fp:
        filedata=fp.read()
        mails=re.findall("\S+@\S+",filedata)
        print("="*50)
        print("Mail ida of student")
        print("="*50)
        for mail in mails:
            print("{}".format(mails))
        print("="*50)
                                    
        
except FileNotFoundError:
    print("File does not found")
