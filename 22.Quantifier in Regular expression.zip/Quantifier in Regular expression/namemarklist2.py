import re
gd="Rossum got 55 marks and whose mail id is rossum@psf@psf.com,Ritche got 88 marks and whose mail id is ritche@sun.com,Gosling got 88 marks and Vk got 44 marks and Adarsh got 77 marks"
namelist=re.findall("[A-Z][a-z]+",gd)
#print("="*50)
#print("Student name")
#print("="*50)
#for name in namelist:
#   print("{}".format(name))
#print("="*50)
markslist=re.findall("\d{2}",gd)
#print("="*50)
#print("Student marks")
#print("="*50)
#for marks in markslist:
 #   print("{}".format(marks))
print("="*50)
print("Student name\t\tStudent marks")
print("="*50)
for sn,sm in zip (namelist,markslist):
    print("{}\t\t\t{}".format(sn,sm))
print("-"*50)
