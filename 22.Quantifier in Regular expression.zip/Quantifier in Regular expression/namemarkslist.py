import re
gd="GANESH got 88 marks NANDU got 90 marks RAKESH got 724 marks NIKITA got 88 marks"
namelist=re.findall("[A-Z]+",gd)
print("="*50)
print("Student name")
print("="*50)
for name in namelist:
   print("{}".format(name),end="\t\n")
print("="*50)
markslist=re.findall("\d{2}",gd)
print("Student marks")
print("="*50)
for marks in markslist:
    print("{}".format(marks),end="\t\n")
print("="*50)
print("Student name\tStuent marks")
print("="*50)
for sn,sm in zip(namelist,markslist):
    print("{}\t\t\t{}".format(sn,sm))
print("="*50)
