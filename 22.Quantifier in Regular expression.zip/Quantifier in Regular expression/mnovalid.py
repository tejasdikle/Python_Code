import re
while(True):
    mno=input("Enter ur your mobile number:")
    if(len(mno)==10):
        result=re.search("\d{10}",mno)
        if(result!=None):
            print("ur mobile number valid")
            break
        else:
            print("Ur obile number not valid")
           
    else:
        print("Ur mobile number must contain 10 digit only")
     
