def disp(farmername,crops,incomeperyear):
    print("\t{}\t\t{}\t{}".format(farmername,crops,incomeperyear))
print("="*50)
print("\tfarmername\tcrops\tincome per year")
print("="*50)
disp('bhaurao','graps',450000)
print("="*50)
