def showinfo(customerno,name,age,adress):
    print("\t{}\t\t{}\t{}\t{}".format(customerno,name,age,adress))
#main programm
print("="*70)
print("\tcustomerno\tname\tage\taddress")
print("="*70)
showinfo(1,"tejas",24,"sayyad pimpri tal nashik ")
showinfo(4,"khalid",45," nashik ")    
showinfo(6,"manse",23,"sayyad pimpri ")
showinfo(7,"kvrao",28,"sandmner ")
showinfo(12,"bakrao",70,"vadali ")
print("="*70)
