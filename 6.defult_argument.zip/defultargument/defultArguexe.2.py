#defultAgruexe3.py
import time
def pythoncourse(sno,sname,marks,crs="PYTHON"):
     print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))
     #time.sleep(1)
     
def javacourse(sno,sname,marks,crs='JAVA'):
     print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))
     
    # time.sleep(0.3333)
    
def ccourse(sno,sname,marks,crs='C'):
     print("\t{}\t{}\t{}\t{}".format(sno,sname,marks,crs))
     
    # time.sleep(0.20)
    
#main programm
print("="*50)
print("\tsno\tsname\tmarks\tcourse")
print("="*50)
pythoncourse(111,"tejas",98)
javacourse(222,"rahul",45)
ccourse(333,"prasad",98)    
print("="*50)
