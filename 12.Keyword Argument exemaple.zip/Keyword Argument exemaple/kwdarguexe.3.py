def dispinfo(eno,ename,sal,cname):
    print("\t{}\t{}\t{}\t{}".format(eno,ename,sal,cname))
    
#main programm
print("="*50)
print("\teno\tename\tsal\tcname")
print("="*50)
dispinfo(111,"TRAVIS",4.3,"PSF")
dispinfo(eno=111,ename="Goswami",sal=4.3,cname="PSF")
dispinfo(222,'tejas',9.4,'wipro')

#dispinfo(cname="hcl",eno=100,"sanjay",5.6)-----------Syntax Error
