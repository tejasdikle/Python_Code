def dispinfo(eno,ename,sal,cnt="INDIA"):

    print("\t{}\t{}\t{}\t{}".format(eno,ename,sal,cnt))
   

#main programm
print("="*50)
print("\teno\tename\tsal\tcnt")
print("="*50)
dispinfo(111,"Tejas",4.3)
dispinfo(222,"travis",90.3)
dispinfo(333,"Guido",9.3)
print("="*50)
