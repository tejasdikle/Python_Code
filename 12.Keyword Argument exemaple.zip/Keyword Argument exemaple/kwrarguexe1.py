#kwdargex1.py
def dispepminfo(eno,ename,salary,cname):pass


#main programm
dispepminfo(111,'rossum',3,4,'TCS')
    
