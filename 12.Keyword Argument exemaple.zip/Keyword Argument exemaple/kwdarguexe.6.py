def disp(a=10,b=20,c=30,d=40):
    print("\t{}\t{}\t{}\t{}".format(a,b,c,d))
print("="*50)
print("\ta\tb\tc\td")
print("="*50)
disp()
