#kwdargex1.py
def dispempinfo(eno,ename,salary,cname='TCS'):
    print("\t{}\t{}\t{}\t{}".format(eno,ename,salary,cname))
    
def dispempinfr(eno,ename,salary,cname='INFOSYS'):
    print("\t{}\t{}\t{}\t{}".format(eno,ename,salary,cname))

#main programm
print("="*50)
print("\teno\tename\tsalary\tcname")
print("="*50)
dispempinfo(111,'rossum',3.4,'TCS')
dispempinfr(222,'Tejas',7.5)
dispempinfr(333,'rahul',1.3)
print("="*50)
    
