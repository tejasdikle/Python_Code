def disp(a=10,b=20,c=30,d=40):
    print("\t{}\t{}\t{}\t{}".format(a,b,c,d))
#main programm
print("="*50)
print("\ta\tb\tc\td")
print("="*50)
disp(10,20,30,40)
disp(d=40,c=30,b=20,a=10)
disp(10,20,d=40,c=30)
disp(40,30,20,10)
print("="*50)
