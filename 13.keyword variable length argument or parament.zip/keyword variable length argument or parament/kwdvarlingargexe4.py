#purekwdvarlenargexe4.py
def findtotalmarks(sname,cls,**submarks):

    print("="*50)
    print("Student name :{}".format(sname))
    print("Student class:{}".format(cls))
    print("="*50)
    totalmarks=0
    print("\tSubject\t\tMarks")
    for s,m in submarks.items():
        print("\t{}\t\t{}".format(s,m))
        totalmarks=totalmarks+m
        
    else:
        print("="*50)
        print("Total mark={}".format(totalmarks))
        print("Average={}".format(totalmarks/len(submarks)))
        Average=(totalmarks/len(submarks))
   
        
#main programm
findtotalmarks("Tejas","XII",hind=49,english=87,marathi=90,science=80)
findtotalmarks("Narayan","B-TECH",c=90,cpp=98,python=100,django=89,htmal=45)
findtotalmarks("Shrikant","M-TECH",bio=45,tech=94,physics=60,ict=56)
