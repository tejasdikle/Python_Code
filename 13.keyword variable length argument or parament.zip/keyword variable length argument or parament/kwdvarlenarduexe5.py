def findtotalmarks(stname,cls,**submarks):
    print("="*50)
    print("Student name:",stname)
    print("Student class:",cls)
    print("="*50)
    totalmarks=0
    for s,m in submarks.items():
        totalmarks=totalmarks+m
        print("\t{}---->\t{}".format(s,m))
        
    print("="*50)
    print("totalmarks:{}".format(totalmarks))
    print("Persecentage :{}".format(totalmarks/len(submarks)))
    grade1="DISTINCTION"
    grade2="PASS"
    grade3="FAIL"
    totmarks=((totalmarks/len(submarks)))
    if (totmarks>=75) :
        print("student grade:{}".format(grade1))
    else:
        if(totmarks<=75) and (totmarks>=50):
            print("student grade:{}".format(grade2))
        else:
            print("student grade:{}".format(grade3))
   
    
            
            
#main programm
findtotalmarks("Tejas","X",Hindi=78,English=88,Math=90,Social_science=98)
findtotalmarks("Travis","XI",Math=45,Socialscience=68,Hindi=78,English=88)
findtotalmarks("Guido","XII",physics=78,chemistry=98,Bio=78,Btst=67)
findtotalmarks("Rossum","Diploma",physics=78,chemistry=18,English=90)
findtotalmarks("Ven","B-tech",c=36,cpp=48,python=47)
