def showinfo(**n):
    print("="*50)
    print("Type of n ={} and number of element={}".format(type(n),len(n)))
    print("="*50)
    for x,y in n.items():
        print("\t{}---->{}".format(x,y))
    else:
        print("="*50)




#main programm
showinfo(sno=10,sname="tejas",M1=20,M2=30,M3=50)
showinfo(eno=20,ename="raj",sal=9.3)
showinfo(tno=30,tname="nana",dsg="SE")
showinfo(name="Agarwal")
