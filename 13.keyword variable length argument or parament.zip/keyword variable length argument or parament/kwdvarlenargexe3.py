def showinfo(SSID,crs="PYTHON",**n):
    print("="*50)
    print("Type of n ={} and number of value ={}".format(type(n),len(n)))
    print("Security id={}".format(SSID))
    print("Type of course={}".format(crs))
    print("="*50)
    for x,y in n.items():
        print("\t{}---->{}".format(x,y))
    else:
        print("="*50)
#main programm
showinfo(111,eno=10,ename="travis",sal=9.3,crs="JAVA")
showinfo(222,sno=20,sname="Tejas",cname="HCL")
showinfo(333,tno=30,tname="rana",crs="HTML")
