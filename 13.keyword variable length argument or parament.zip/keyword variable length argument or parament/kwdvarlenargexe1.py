#purekwdvarlenargexe1.py
def showinfo(cname="INFOSYS",**n):
    print("="*50)
    print("Type ={} and number of element {}".format(type(n),len(n)))
    print("Name of the company={}".format(cname))
    print("="*50)
    for x,y in n.items():
        print("\t{}----->{}".format(x,y))
    else:
        print("="*50)

#main programm
showinfo(eno=111,ename="Travis",sal=9.9,cname="HCL")
showinfo(sno=222,sname="Tejas",sal=8.4)
showinfo(tno=333,tname="Guido",cname="Wipro")
showinfo(kno=444,kname="Rossum",sal=10)
