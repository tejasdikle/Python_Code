class ZeroDivisionError(Exception):pass
