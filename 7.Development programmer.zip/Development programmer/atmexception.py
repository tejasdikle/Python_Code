class DepositeError(Exception):pass
class WithdrawError(BaseException):pass
class InsuffundError(Exception):pass
class ZeroError(Exception):pass
