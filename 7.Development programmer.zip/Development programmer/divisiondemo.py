from divi import division
res=division(10,0)
print("Result=",res)
