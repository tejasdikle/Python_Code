from atmdemo import atmproject
import sys,time
def atmprojrun():
    attempts=1
    while(True):
        pw=(input("Enter your password"))
        print("Wel-come to the ATM project")
        print("Wait for few second")
        time.sleep(2)
        if(pw=="4226"):
            atmproject()
        else:
            if(attempts==3):
                print("I think u are not correct person")
                sys.exit()
            attempts=attempts+1
atmprojrun()
