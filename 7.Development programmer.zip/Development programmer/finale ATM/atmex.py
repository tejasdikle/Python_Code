class ZeroError(Exception):pass
class DepositeError(BaseException):pass
class WithdrawError(Exception):pass
class InsuffundError(Exception):pass
