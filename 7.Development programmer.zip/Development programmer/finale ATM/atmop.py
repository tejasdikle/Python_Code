from atmex import ZeroError,DepositeError,WithdrawError,InsuffundError
bal=500
def deposite():
    global bal
    damt=int(input("Enter the deposite amount:"))
    if(damt==0):
        raise ZeroError
    elif(damt<0):
        raise DepositeError
    else:
        
        print("="*30)
        bal=bal+damt
        print("{} RS Credited on your account XXXXXXX123".format(damt))
        print("Your account balance is :{}".format(bal))
def withdraw():
    global bal
    wamt=int(input("Enter the withdraw amount:"))
    if(wamt==0):
        raise ZeroError
    elif(wamt<0):
        raise WithdrawError
    elif((wamt+500)>bal):
        raise InsuffundError
    else:
        #global bal
        print("="*30)
        bal=bal-wamt
        print("{} RS Debited from your account XXXXXXX123".format(wamt))
        print("Your account balance is :{}".format(bal))
def balenq():
    print("="*40)
    print("Your current balnce is :{}".format(bal))
    print("="*40)
