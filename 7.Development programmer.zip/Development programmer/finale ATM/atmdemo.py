from atmenu import menu
from atmop import deposite,withdraw,balenq
from atmex import ZeroError,DepositeError,WithdrawError,InsuffundError
def atmproject():
#import sys
    try:
        while(True):
            menu()
            ch=int(input("Enter your choice:"))
            match(ch):
                case 1:
                    try:
                        deposite()
                    except ZeroError:
                        print("Dont enter zero for depositing the amount")
                    except DepositeError:
                        print("Dont enter negative amount")
                    except ValueError:
                        print("Don't enter str ,symboland alpha numeric value")
                case 2:
                    try:
                        withdraw()
                    except ZeroError:
                        print("Dont enter zero for withdraw the amount")
                    except WithdrawError:
                        print("Dont enter negative amount")
                    except InsuffundError:
                        print("Your balance is low U can't withraw")
                    except ValueError:
                        print("Don't enter str ,symboland alpha numeric value")
                case 3:
                    balenq()
                case 4:
                    print("THANK YOU FOR USING THIS PROGRAMM")
                    exit()
    except ValueError:
        print("Don't enter str ,symboland alpha numeric value")
      
