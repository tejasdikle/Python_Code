def menu():
    print("="*50)
    print("ATM OPERATION")
    print("="*50)
    print("1.Deposite")
    print("2.Withdraw")
    print("3.Bal enq")
    print("4.exit")
    print("="*50)
    
