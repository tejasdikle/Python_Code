from atmdemo import atmproject
import getpass
def atmprojrun():
    attempt=1
    while(True):
        pw=getpass(prompt=input("Enter ur password"))
        if(pw=="Tejas@2001"):
            atmproject()
        else:
            if(attempt==3):
                print("Try after some time")
                sys.exit()
            ampt=attempt+1
atmprojrun()
