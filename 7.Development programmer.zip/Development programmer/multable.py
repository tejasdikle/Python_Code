#multable.py
from tableexep import ZeroError,NegativeNumberError
def table(n):
    if(n==0):
        raise ZeroError
    elif(n<=0):
        raise NegativeNumberError
    elif(n>= 0):
            print("-"*40)
            print("Mul Table for :{}".format(n))
            print("-"*40)
            for i in range (1,11):
                print("{}*{}={}".format(n,i,n*i))
            else:
                print("-"*40)


