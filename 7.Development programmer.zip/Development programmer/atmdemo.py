from atmenu import menu
import sys
from atmoperation import deposite,withdraw,balenq
from atmexception import ZeroError,DepositeError,WithdrawError,InsuffundError
def atmproject():
    try: 
        while(True):
            menu()
            ch=int(input("Enter your choice:"))
            match(ch):
                case 1:
                    try:
                        deposite()
                    except ZeroError:
                        print("Dont enter zero amount for deposite")
                    except ValueError:
                        print("Dont enter str and symbol")
                    except DepositeError:
                        print("Dont enter -ve number ")
                case 2:
                    try:
                        withdraw()
                    except ZeroError:
                        print("Dont enter zero amount for withdraw")
                    except ValueError:
                        print("Dont enter str and symbol")
                    except WithdrawError:
                        print("Dont enter -ve number ")
                    except InsuffundError:
                        print("You can maintain your account with rupees 500")
                case 3:
                    balenq()
                case 4:
                    print("Thank you for using this programm")
                    exit()
                case _:
                    
                    print("Your selection is wrong:")
    except ValueError:
        print("Dont enter str and symbol or alpha numeric")
atmproject()
