from atmexception import ZeroError,DepositeError,WithdrawError,InsuffundError
bal=500
def deposite():
    damt=int(input("Enter your deposite amount:"))
    if(damt==0):
        raise ZeroError
    elif(damt<0):
        raise DepositeError
    else:
        global bal
        bal=bal+damt
        print("="*50)
        print("{} rs credited in your account".format(damt))
        print("Now your availbal bal:{}".format(bal))
        print("="*50)
def withdraw():
    global bal
    wamt=int(input("Enter ur withdraw amount:"))
    if(wamt==0):
        raise ZeroError
    elif(wamt<0):
        raise WithdrawError
    elif((wamt+500)>bal):
        raise InsuffundError
    else:
        bal=bal-wamt
        print("="*50)
        print("{} rs debited in your account".format(wamt))
        print("Now your availbal bal:{}rs".format(bal))
        print("="*50)
    
def balenq():
    print("="*50)
    print("Your availble balance is:{}".format(bal))
    print("="*50)
    
