def menu():
    print("="*50)
    print("ATM OPERATION")
    print("="*50)
    print("1.Deposite")
    print("2.Withdraw")
    print("3.Bal enq")
    print("4.exit")
    print("="*50)

while(True):
    menu()
    ch=int(input("Enter ur choice:"))
    match(ch):
        case 1:
            bal=500
            damt=int(input("Enter ur amount:"))
            bal=bal+damt
            print("="*50)
            print("Your deposit amount :{}".format(damt))
            print("Now ur balance :{}".format(bal))
            print("="*50)
            
        case 2:
            wamt=int(input("Enter ur withdraw amount"))
            bal=bal-wamt
            if (bal<=500) or (bal==0):
                print("U cant withdraw the amount")
            elif(bal==0):
                print("Insuficient fund")
            else:
                
                print("="*50)
                print("Your withdraw amount :{}".format(wamt))
                print("Now ur balance :{}".format(bal))
                print("="*50)
        case 3:
            bal=500
            print("Your current balance is:{}".format(bal))
        case 4:
            exit()
