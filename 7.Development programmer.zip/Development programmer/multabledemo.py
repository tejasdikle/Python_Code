#multabledemo.py
from multable import table
from tableexep import ZeroError,NegativeNumberError
#while(True):
    try:
        n=int(input("Enter the number for table:"))
        table(n)
    except ZeroError:
        print("Dont enter zero")
    except NegativeNumberError:
        print("Dont enter negative number")
    except ValueError:
        print("Dont enter strs and symbol")
    except:
        print("Some went wrong")

                                                                        
