class ZeroError(Exception):pass
class NegativeNumberError(BaseException):pass
