from kvr import ZeroDivisionError
def division (a,b):
    if(b==0):
        raise ZeroDivisionError
    else:
        return (a/b)
    
