#globalfunexe1.py
a=10
b=20
c=30
d=40
def operation():
    global a,b,c,d
    a=a+1
    b=b+1
    c=c+1
    d=d+1
    print(a,b,c,d)
operation()
