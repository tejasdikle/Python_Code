a=10
b=20
c=30
d=400
def operation():
    #global a,b,c,d
    a1=100
    b1=200
    c1=300
    d1=400
    res=a+b+c+d+ globals()['a']+ globals().get('b')+ globals()['c']+ globals()['d']
    print(res)
operation()
    
