def update1():
    global a,b
    a=a+1
    b=b+1
def update2():
    global a,b
    a=a*10
    b=b*10

#main programm
a,b=1,2
print("Value of a:{} and value of b:{} in main programm before updation".format(a,b))
update1()
print("Value of a:{} and value of b:{} in main programm after updation".format(a,b))
update2()
print("Value of a:{} and value of b:{} in main programm after updation".format(a,b))
