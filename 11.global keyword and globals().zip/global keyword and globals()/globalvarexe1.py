a=10
def access():
    global a
    a=a+22
    print("value inside the assecs()",a)
#main programm
print("value before access()",a)
access()
print("value after access()",a)
