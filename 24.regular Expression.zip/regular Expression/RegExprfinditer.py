import re
gd="python is an oop language,python is also fun langauge ,python"
sp="python"
obj=re.finditer(sp,gd)
for val in obj:
    print(val)
