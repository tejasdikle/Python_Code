import re
obj=re.finditer("[a^b]","weakc@l#b$i%am&c*u0ha)bn!@jcdlvc")# only earch value how many time ask
for val in obj:
    print("start index :{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
    
