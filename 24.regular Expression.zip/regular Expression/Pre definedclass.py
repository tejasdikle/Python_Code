import re
obj=re.finditer('\w','!@#$%^&*(assfJSAD54132HF')
for val in obj:
    print("start index:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
