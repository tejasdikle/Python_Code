import re
obj=re.finditer("\W","123klsda fLJNSAD&^(*&")#search only special symbol data
for val in obj:
    print("strat index:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
