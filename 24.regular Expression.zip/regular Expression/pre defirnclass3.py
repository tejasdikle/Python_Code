import re
obj=re.finditer("\D","123klsdafLJNSAD&^(*&")#search alphabet & symbol data
for val in obj:
    print("strat index:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
