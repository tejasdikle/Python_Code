import re
gd="python is an oop language.python is also fun language"
sp="python"
obj=re.findall(sp,gd)
for val in obj:
    print("Number of occerences :{} :{}".format(sp,len(sp)))
   
