import re
obj=re.finditer("\d","123klsda fLJNSAD&^(*&")#search only digit data
for val in obj:
    print("strat index:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
