import re
obj=re.finditer("\S","123klsda fLJNSAD&^(*&")#search all data
for val in obj:
    print("strat index:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
