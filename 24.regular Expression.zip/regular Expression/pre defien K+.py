import re
obj=re.finditer("k+","kvkkvkkkvkkkkvkkkk")# print k in series
for val in obj:
    print("start undex:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
