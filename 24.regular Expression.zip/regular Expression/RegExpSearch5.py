import re
obj=re.finditer("[^a-z]","weakclbiamcuhanjcdlvc")
for val in obj:
    print("start index :{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
    
