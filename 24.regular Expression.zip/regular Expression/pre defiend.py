import re
obj=re.finditer(".","kvkkvkkkvkkkkvkkkk")#print all
for val in obj:
    print("start undex:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
