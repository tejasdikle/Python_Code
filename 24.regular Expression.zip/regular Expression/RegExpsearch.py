import re
dg="python is an oop language .python is also fun languge"
sp='kvr'
obj=re.search(sp,dg)
if(obj!=None):
    print("="*50)
    print("{} value found and search is successfully".format(sp))
    print("="*50)
else:
    print("="*50)
    print("{} value not found and search is unsuccessfully".format(sp))
    print("="*50)
