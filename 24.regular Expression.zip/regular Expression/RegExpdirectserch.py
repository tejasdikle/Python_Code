import re
obj=re.finditer("[^A-Za-z]","SjidMI&*&$#@ODSNjncj")
for val in obj:
    print("start index:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
    
