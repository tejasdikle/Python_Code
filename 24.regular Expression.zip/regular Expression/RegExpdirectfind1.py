import re
obj=re.finditer("[abc]","weakclbiamcuhanjcdlvc")
for val in obj:
    print("start index :{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
    
