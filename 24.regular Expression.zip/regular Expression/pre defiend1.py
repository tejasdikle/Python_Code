import re
obj=re.finditer("k","kvkkvkkkvkkkkvkkkk")#print only k
for val in obj:
    print("start undex:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
