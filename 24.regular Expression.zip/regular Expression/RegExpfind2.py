import re
gd="python is an oop language .python also fun language"
sp="python"
obj=re.finditer(sp,gd)
noc=0
print("="*50)
for val in obj:
    print("start index:{} end index:{} value: {}".format(val.start(),val.end(),val.group()))
    noc=noc+1
print("="*50)
print("Number of occerence :{}:{}".format(sp,noc))
print("="*50)
