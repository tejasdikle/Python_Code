import re
gd="python is an oop language.python also fun langauge"
sp="python"
obj=re.finditer(sp,gd)
for val in obj:
    print("start index:{} end index:{} value:{}".format(val.start(),val.end(),val.group()))
    
