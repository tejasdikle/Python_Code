class student:
    def adddata(self):
        self.sno=int(input("Enter std no:"))
        self.sname=input("Enter std name:")
        self.marks=float(input("Enter student marks:"))
class hyd:
    @staticmethod
    def despobjdata(k):
        for k1,v1 in k.__dict__.items():
            print("{}------>{}".format(k1,v1))


s=student()
s.adddata()
hyd.despobjdata(s)
