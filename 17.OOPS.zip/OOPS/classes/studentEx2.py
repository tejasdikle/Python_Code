class student:
    crs="python"
s1=student()
s2=student()
s1.stdno=111
s1.name='ram'
s1.marks=85.34
print("Content in s1 after adding=",s1.__dict__,student.crs)
s2.stdno=112
s2.name='ramas'
s2.marks=45
print("Content in s1 after adding=",s2.__dict__,student.crs)
print("="*25)
print("Student number={}".format(s1.stdno))
print("Student name={}".format(s1.name))
print("Student marks={}".format(s1.marks))
print("Student cource={}".format(s1.crs))
print("="*50)

