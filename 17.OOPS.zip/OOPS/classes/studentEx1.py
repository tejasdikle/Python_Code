class student:
    crs="python"
s=student()
print("content in s before adding=",s.__dict__)
s.studno=111
s.sname='ram'
s.marks=94.34
print("content in s after adding=",s.__dict__,student.crs)
