import pickle
try:
    with open("studpickleEx1","rb")as fp:
        print("="*50)
        print("\tStud no\t\tStud name\tStudmarks")
        print("="*50)
        while(True):
            try:
                obj=pickle.load(fp)
                obj.despdata()
            except EOFError:
                print("="*50)
                break
except FileNotFoundError:
    print("Dot enter str")
        

    
