class student:
    def adddata(self):
        print("id of s1 programm in student class of adddata ()=",id(self))
        print("id of s1 programm in student class of adddata ()=",id(self))

