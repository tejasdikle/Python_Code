class student:
    @ classmethod
    def getcourse(cls):
        cls.crs1="PYTHON"
        cls.crs2="DJANGO"
    def adddata(self):
        self.sno=int(input("Enter student no:"))
        self.sname=input("Enter student name:")
        self.marks=float(input("Enter studnet marks:"))
    def dispdata(self):
        print("Student no:{}".format(self.sno))
        print("Student name:{}".format(self.sname))
        print("Student marks:{}".format(self.marks))
        print("Student crs1:{}".format(student.crs1))
        print("Student crs2:{}".format(student.crs2))
#student.getcourse()
s=student()
s.getcourse()
s.adddata()
print("="*50)
s.dispdata()
print("="*50)
