class student:
    def student(self):
        print("id of s in adddata()=",id(self))


#main programm
s=student()
print("id of s in adddata()=",id(s))
s.adddata()
