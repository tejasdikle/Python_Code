from selfEx2 import student
#main programm
s1=student()
print("id of s1 in main programm=",id(s1))
s1.adddata()
