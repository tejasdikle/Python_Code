import time
class sum:
    def readvalue(self):
        self.a=float(input("Enter the value of a:"))
        self.b=float(input("Enter the value of b:"))
    def addop(self):
        self.c=self.a*self.b
        print("value of a:{}".format(self.a))
        print("Value of b:{}".format(self.b))
        print("sum ={}".format(self.c))
    

#main programm
s=sum()
s.readvalue()
print("-"*30)
s.addop()
print("-"*30)
