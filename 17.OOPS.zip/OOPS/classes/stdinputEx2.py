import pickle
with open("stdinputEx.data","rb") as fp:
     print("="*110)
     print("\tstd no\tstd name\tphy marks\tmath marks\tchy marks\tBio marks\tpyth marks")
     print("="*110)
     while(True):
        try:
            obj=pickle.load(fp)
            obj.showdata()
        except EOFError:
            print("="*110)
            break
            
