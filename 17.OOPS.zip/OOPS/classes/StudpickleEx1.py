class student:
    def readvalue(self):
        self.sno=int(input("Enter stident numner:"))
        self.sname=input("Enter student name:")
        self.marks=float(input("Enter student marks:"))
        
    def despdata(self):
        print("\t{}\t\t{}\t\t{}".format(self.sno,self.sname,self.marks))
    
