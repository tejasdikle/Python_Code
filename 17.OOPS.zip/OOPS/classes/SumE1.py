class sum:
    def readvalue(self):
        self.a=float(input("Enter the value of a:"))
        self.b=float(input("Enter the value of b:"))
    def addop(self):
        self.c=self.a*self.b


#main programm
s=sum()
s.readvalue()
s.addop()
print(s.__dict__)
