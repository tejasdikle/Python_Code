import mysql.connector
class student:
    def readstudentvalue(self):
        while(True):
            self.sno=int(input('Enter student no:'))
            if self.sno in range (50,150):
                break
        self.sname=input('Enter student name:')
        while(True):
            self.c=int(input('Enter C subject marks:'))
            if self.c in range (0,101):
                break
        while(True):
            self.cpp=int(input('Enter CPP subject marks:'))
            if self.cpp in range (0,101):
                break
        while(True):
            self.pyt=int(input('Enter PYTHON subject marks:'))
            if self.pyt in range (0,101):
                break
            
    #print(self.c,self.cpp,self.pyt,self.totalm,self.per,self.grade)

    def calrecord(self):
        self.totalm=self.c+self.cpp+self.pyt
        self.per=self.totalm/300*100
        if (self.c>40) or (self.cpp>40) or (self.pyt>40):
            self.grade="FAIL"
        if self.totalm in range(250,300):
            self.grade="DISTN"
        if self.totalm in range(200,250):
            self.grade="FIRST"
        if self.totalm in range(150,200):
            self.grade="SECOND"
        if self.totalm in range(100,150):
            self.grade="THIRD"
        if self.totalm in range(70,100):
            self.grade="लायकी नाही "
    def connect(self):
        
            con=mysql.connector.connect(host="localhost",user="root",passwd="Tejas@2001",database="class")
            cur=con.cursor()
            q="insert into result value(%d,'%s',%d,%d,%d,%d,%f,'%s')"
            cur.execute(q%(self.sno,self.sname,self.c,self.cpp,self.pyt,self.totalm,self.per,self.grade ))
            con.commit()
            print("-"*50)
            print("{} Data save successfully".format(cur.rowcount))
            print("-"*50)
            ch=input("Do u want to insert another record(yes/no):")
            if(ch.lower()=="no"):
                print("Thank u using programm")
                
            print('-'*50)
        
            


s=student()
s.readstudentvalue()
s.calrecord()
s.connect()
