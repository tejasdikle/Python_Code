class student :
    def adddata(self):
        self.sno=int(input("Enter student no:"))
        self.sname=input("Enter student name:")
        self.marks=float(input("Enter student marks:"))
    def dispdata(self):

        print("Student no=\t{}".format(self.sno))
        print("Student name=\t{}".format(self.sname))
        print("Student marks=\t{}".format(self.marks))

s1=student()
s2=student()
print("First student info")
print("-"*50)
s1.adddata()
print("="*30)
print("Content of first student information")
print("="*30)
s1.dispdata()
print("-"*50)
print("second student info")
print("-"*50)
s2.adddata()
print("="*30)
print("Content of second student information")
print("="*30)
s2.dispdata()
print("-"*30)
