class student:
    def readstdvalue(self):
        self.sno=int(input("Enter student number:"))
        self.sname=(input("Enter student name:"))
        self.sm1=int(input("Enter physic marks:"))
        self.sm2=int(input("Enter math marks:"))
        self.sm3=int(input("Enter chemestry marks:"))
        self.sm4=int(input("Enter Bio-logy marks :"))
        self.sm5=int(input("Enter python marks:"))
    def showdata(self):
        print("\t{}\t{}\t\t{}\t\t{}\t\t{}\t\t{}\t\t{}".format(self.sno,self.sname,self.sm1,self.sm2,self.sm3,self.sm4,self.sm5))
        
