import pickle
from StudpickleEx1 import student
while(True):
    with open("studpickleEx1","ab")as fp:
        s=student()
        s.readvalue()
        pickle.dump(s,fp)
        print("="*50)
        print("Successfully save")
        print("="*50)
        ch=input("do u insert another record(y/n):")
        if(ch=='n'):
            print("Thank u ")
            break
