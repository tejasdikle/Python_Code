class student:
    def adddata(self):
        self.sno=int(input("Enter student number:"))
        self.sname=input("Enter student name:")
        self.marks=float(input("Enter student marks:"))
s1=student()
s2=student()
print("Content of s1 before reading=",s1.__dict__)
s1.adddata()
print("Content of s1 after read=",s1.__dict__)
print("==============OR===============")
print("Content of s2 before reading=",s2.__dict__)
s2.adddata()
print("Content of s2 after read=",s2.__dict__)
