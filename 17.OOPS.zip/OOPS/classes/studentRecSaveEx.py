import pickle
from stdinputEx import student
try:
    while(True):
        with open("stdinputEx.data","ab") as fp:
            s=student()
            s.readstdvalue()
            pickle.dump(s,fp)
            print("="*50)
            print("Students university record save successfully")
            print("="*50)
            ch=input("Do u have save one more record(y/n:")
            if(ch=="n"):
                print("Thank u for using this programm")
                break
            else:
                print("="*50)
            
except FileNotFoundError as fd:
    print("File does not exist",fd)
