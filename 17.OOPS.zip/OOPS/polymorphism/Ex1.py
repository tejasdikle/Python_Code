class teacher:
    def readsub(self):
        print("Teacher advise read 2 hours")
class lazystudent(teacher):
    def readsub(self):
        print("lazy student not read 2 nours:")

class perfectstudent(teacher):
    def readsub(self):
        print("perfect student read 2 hours:")
        

t=teacher()
t.readsub()
ls=lazystudent()
ls.readsub()
ps=perfectstudent()
ps.readsub()
