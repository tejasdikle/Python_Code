class circle:
    def area(self):
        self.r=int(input("Enter radius of circle:"))
        self.ac=3.14*self.r**2
        print("Area of circle=",self.ac)
class rect(circle):
    def area(self):
        self.l=int(input("Enter length of rect:"))
        self.b=int(input("Enter breath of rect:"))
        self.ar=self.l*self.b
        print("Area of rect",self.ar)
        super().area()

#MAIN PROGRAMM
r=rect()
print("="*50)
r.area()
print("="*50)
