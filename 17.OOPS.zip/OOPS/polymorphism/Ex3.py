class circle:
    def area(self):
        self.c=int(input("Enter redius of circle:"))
        self.ac=3.14*self.c**2
        print("=" * 50)
        print("Area of circle=",self.ac)
class rect:
    def area(self):
        self.l = int(input("Enter length:"))
        self.b=int(input("Enter breath:"))
        self.ar=self.l*self.b
        print("=" * 50)
        print("Area of rect=",self.ar)

class squre(rect,circle):
    def area(self):
        self.s=int(input("Enter side value:"))
        self.As=self.s**2
        print("Area of squre=",self.As)
        #super().area()
        print("=" * 50)
        circle().area()
        print("=" * 50)
        rect().area()
        print("="*50)
        #squre().area()'''


s=squre()
s.area()
