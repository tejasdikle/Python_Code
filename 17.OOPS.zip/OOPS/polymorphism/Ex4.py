class circle:
    def area(self,r):
        self.c=3.14*r**2
        print("Area of circle",self.c)
class rect:
    def area(self,l,b):
        self.r=l*b
        print("Area of rect",self.r)
class square(rect,circle):
    def area(self,s):
        self.s=s**2
        print("Area of square",self.s)
        #circle.area(self,int(input("Enter radius of circle")))
        #rect.area(self,int(input("Enter lentgh")),int(input("Enter breath :")))
        circle.area(self,4)
        rect.area(self,4,5)

s=square()
#s.area(int(input("enter side")))
s.area(6)
