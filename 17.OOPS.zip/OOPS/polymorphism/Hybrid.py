class c1:
    def x(self):
        print("c1-x()")
class c2(c1):
    def x(self):
        print("c2-x()")
class c4(c1):
    def x(self):
        print("c3-x()")
class c3(c2) :
    def x(self):
        print("c4-x()")
class c5(c4):
    def x(self):
        print("c5-x()")
class c6(c5):
    def x(self):
        print("c6-x()")
class c7(c6):
    def x(self):
        print("c7-x()")
        #super().x()


a=c7()
a.x()
