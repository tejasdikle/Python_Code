from empl import employee

e=employee()
e.getempdel()
e.despempdel()
