from std import student

s=student()
s.getstddel()
s.despstddel()
