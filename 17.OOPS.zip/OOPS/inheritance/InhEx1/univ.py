class university:
    def getunivdel(self):
        self.uname=input("Enter University name:")
        self.uloc=input("Enter location university:")
        self.per=input("Enter president of university:")
    def despunivdel(self):
        print("="*50)
        print("Univ Datials")
        print("=" * 50)
        print("University name:\t{}".format(self.uname))
        print("University location:\t{}".format(self.uloc))
        print("University president:\t{}".format(self.per))
        print("=" * 50)
        
