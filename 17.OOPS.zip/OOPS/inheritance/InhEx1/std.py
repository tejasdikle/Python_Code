from coll import college
class student(college):
    def getstddel(self):
        self.sno = int(input("Enter student number:"))
        self.sname = input("Enter student name:")
        self.smarks=float(input("Enter student marks:"))
        self.s = input("Enter student staff:")

    def despstddel(self):
        self.getcolldel()
        self.despcolldel()
        print("=" * 50)
        print("student Datials")
        print("=" * 50)
        print("student no:\t{}".format(self.sno))
        print("student name:\t{}".format(self.sname))
        print("student marks:\t{}".format(self.smarks))
        print("student staff:\t{}".format(self.s))
        print("=" * 50)
