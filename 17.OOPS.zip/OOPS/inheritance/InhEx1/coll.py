from univ import university
class college(university):
    def getcolldel(self):
        self.cname = input("Enter college name:")
        self.cloc = input("Enter location college:")
        self.p = input("Enter principal of college:")

    def despcolldel(self):
        self.getunivdel()
        self.despunivdel()
        print("=" * 50)
        print("College Datials")
        print("=" * 50)
        print("college name:\t\t{}".format(self.cname))
        print("college location:\t{}".format(self.cloc))
        print("college principal:\t{}".format(self.p))
        print("=" * 50)
