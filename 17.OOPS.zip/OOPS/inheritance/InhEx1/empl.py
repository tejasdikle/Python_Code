from comp import company
class employee(company):
    def getempdel(self):
        self.eno=input("Enter employes number:")
        self.ename = input("Enter employee name:")
    def despempdel(self):
        self.getcompdel()
        self.despcompdel()
        print("="*50)
        print("Employess Details")
        print("=" * 50)
        print("Employess number ={}".format(self.eno))
        print("Employees name ={}".format(self.ename))
        print("=" * 50)


