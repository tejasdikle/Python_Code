class company:
    def getcompdel(self):
        self.cno=input("Enter compny number:")
        self.cname = input("Enter compny name:")
    def despcompdel(self):
        print("="*50)
        print("Company Details")
        print("=" * 50)
        print("Company number ={}".format(self.cno))
        print("Company name ={}".format(self.cname))
        print("=" * 50)
        print("=" * 50)

