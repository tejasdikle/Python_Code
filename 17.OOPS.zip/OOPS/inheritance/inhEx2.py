class company:
    def getcompdel(self):
        self.cno=input("Enter compny number:")
        self.cname = input("Enter compny name:")
    def despcompdel(self):
        print("="*50)
        print("Company Details")
        print("=" * 50)
        print("Company number ={}".format(self.cno))
        print("Company name ={}".format(self.cname))
        print("=" * 50)
        print("=" * 50)

class employee(company):
    def getempdel(self):
        self.eno=input("Enter employes number:")
        self.ename = input("Enter employee name:")
    def despempdel(self):
        self.getcompdel()
        self.despcompdel()
        print("="*50)
        print("Employess Details")
        print("=" * 50)
        print("Employess number ={}".format(self.eno))
        print("Employees name ={}".format(self.ename))
        print("=" * 50)
       
e=employee()
e.getempdel()
e.despempdel()
