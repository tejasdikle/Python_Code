import time
class student:
    def __init__(self,sno,sname):
        self.sno=sno
        self.sname=sname
        print("\t{}------>{}".format(self.sno,self.sname))

    def __del__(self):
        print("Garbage collector calling destuctor")

print("-"*30)
print("Content in s")
print("-"*30)
s=student(11,"ram")#GARBAGE COLLECTOR WILL SHOW OBJECT ENDING
print("-"*30)
#*****************************************************************
#print("No longer interest in maintaining s1 object")
print("-"*60)
s=None
print("-"*60)
print("-"*30)
print("Content in s2")#GARBAGE COLLECTOR WILL SHOW OBJECT ENDING
print("-"*30)
s2=student(22,"sham")
print("-"*60)
s2=None
print("-"*60)
#*****************************************************************
print("-"*30)
print("Content in s3")
print("-"*30)
s3=student(33,"damu")
print("-"*60)#GARBAGE COLLECTOR WILL SHOW OBJECT ENDING
s3=None
print("-"*60)
