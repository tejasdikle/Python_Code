class student:
    def __init__(self,a,b):
        self.a=a
        self.b=b
    def __del__(self):
        print("Garbage collector is calling destructor")

print("Programm execution started")
s1=student(10,20)
print("="*50)
print(s1.__dict__)
print("="*50)
s2=student(10,30)
print("Programm execution eneded")
